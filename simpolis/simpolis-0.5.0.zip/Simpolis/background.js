// Šimpoliš - service worker: hlídá SIS, posílá notifikace, přihlašuje.
import {
  SIS_LIST_URL,
  HARMONOGRAM_URL,
  AUTH_HOST,
  signInUrl,
  parseSisList,
  parseHarmonogram,
  parseLoginForm,
  looksLikeLogin,
  extractFlash,
  pageTitle,
  toMs,
} from './parser.js';
import {
  buildCatalog,
  newWatchFromCard,
  defaultAuto,
  matchRows,
  nearRows,
  mayAutoSign,
  needsConfirm,
  isActive,
  iconLevel,
  planNext,
  formatWhen,
  formatDt,
  signinText,
  RHYTHM,
} from './model.js';
import { decryptVault } from './vault.js';
import { readShared, submit, buildSubmission, canUseSharedSis, canUseSharedHarmo, adoptSisRows } from './share.js';
import { fetchStatus, evaluateRelease, isBlocked, STATUS_EVERY_MS, STATUS_MANUAL_GAP_MS } from './release.js';

const ALARM = 'tick';
const WATCHDOG = 'watchdog'; // periodická pojistka, kdyby se řetěz jednorázových alarmů přetrhl
const FETCH_TIMEOUT_MS = 20_000;
const MANUAL_GAP_MS = 30_000; // kontrola při otevření popupu: nejvýš 1× za 30 s
const HARMO_EVERY_MS = 6 * 3600_000;
const BATCH_LIMIT = 3; // víc nových akcí najednou = jedna souhrnná notifikace

const DEFAULTS = {
  watches: [],
  hidden: {}, // karta -> { title, when }: „Nezajímá mě“
  known: null, // slot (datum|čas) -> { open }: co už uživatel ví; null = první běh
  sis: { lastCheck: 0, nextCheck: 0, nextReason: '', rows: [], error: null, errStreak: 0, source: 'own' },
  harmo: { lastCheck: 0, rows: [], error: null, source: 'own' },
  share: { sisAt: 0, harmoAt: 0, sentAt: 0, error: null },
  release: { checkedAt: 0, state: 'ok', reason: null, latest: null, message: '', url: null, notified: '', error: null }, // sisAt = poslední pokus (i neúspěšný), sentAt = poslední úspěch
  session: { status: 'unknown', since: null, partial: true, notified: false, log: [] },
  autoPaused: false,
  pauseReason: '',
  vaultFailed: false,
  vaultLockNotified: false,
  heartbeat: true,
  heartbeatDate: '',
  responses: [],
  notifs: {}, // id notifikace -> akce tlačítek
};

// ---------- úložiště a serializace ----------

// Jeden service worker = jedna fronta. Kontrola, přihlášení i příkazy
// z popupu běží za sebou, takže nikdy neběží dva pokusy najednou.
let chain = Promise.resolve();
function serial(fn) {
  const run = chain.then(fn, fn);
  chain = run.catch((e) => console.error('[Šimpoliš]', e.message));
  return run;
}

async function load() {
  const st = await chrome.storage.local.get(null);
  for (const [k, v] of Object.entries(DEFAULTS)) if (st[k] === undefined) st[k] = structuredClone(v);
  if (!Array.isArray(st.watches)) st.watches = [];
  st.watches = st.watches.filter((w) => w.key && w.source); // stará verze (Ostrahangutan) se zahodí
  return st;
}

async function save(st) {
  const { vault, ...rest } = st; // trezor zapisuje jen stránka Nastavení a popup
  await chrome.storage.local.set(rest);
}

async function vaultLocked(st) {
  if (!st.vault) return false;
  const { vaultKey } = await chrome.storage.session.get('vaultKey');
  return !vaultKey;
}

async function credentials(st) {
  if (!st.vault) return { state: 'none' };
  const { vaultKey } = await chrome.storage.session.get('vaultKey');
  if (!vaultKey) return { state: 'locked' };
  try {
    return { state: 'unlocked', ...(await decryptVault(st.vault, vaultKey)) };
  } catch {
    return { state: 'locked' };
  }
}

const catalogOf = (st) => buildCatalog(st.harmo.rows, st.sis.rows, Date.now());
const findCard = (st, key) => {
  const c = catalogOf(st);
  return [...c.web, ...c.sisOnly].find((x) => x.key === key) ?? null;
};
const pageUrl = (focus) => chrome.runtime.getURL(`popup.html?page=1${focus ? `&focus=${encodeURIComponent(focus)}` : ''}`);

// ---------- notifikace ----------

// actions: { click: 'sis' | 'page' | 'harmo', buttons: [{ title, do, key }] }
function notify(st, title, message, { sticky = false, click = 'sis', key = null, buttons = [] } = {}) {
  const id = `n${Date.now()}${Math.random().toString(36).slice(2, 6)}`;
  const opts = {
    type: 'basic',
    iconUrl: 'icons/128.png',
    title: `Šimpoliš (beta): ${title}`,
    message: String(message).slice(0, 300),
    priority: 2,
    requireInteraction: sticky,
  };
  if (buttons.length) opts.buttons = buttons.slice(0, 2).map((b) => ({ title: b.title }));
  chrome.notifications.create(id, opts);
  st.notifs[id] = { click, key, buttons: buttons.map(({ do: d, key: k, data }) => ({ do: d, key: k ?? key, data })), at: Date.now() };
  const ids = Object.keys(st.notifs);
  if (ids.length > 40) for (const old of ids.slice(0, ids.length - 40)) delete st.notifs[old];
}

function openTarget(click, key, st) {
  const url =
    click === 'harmo' ? HARMONOGRAM_URL
    : click === 'page' ? pageUrl(key)
    : click === 'release' ? (st?.release?.url ?? pageUrl())
    : SIS_LIST_URL;
  chrome.tabs.create({ url });
}

chrome.notifications.onClicked.addListener((id) =>
  serial(async () => {
    const st = await load();
    const n = st.notifs[id];
    openTarget(n?.click ?? 'sis', n?.key, st);
    chrome.notifications.clear(id);
  })
);

chrome.notifications.onButtonClicked.addListener((id, index) =>
  serial(async () => {
    const st = await load();
    const b = st.notifs[id]?.buttons?.[index];
    chrome.notifications.clear(id);
    if (!b) return;
    if (b.do === 'sis') return openTarget('sis');
    const res = await handle(
      b.do === 'watch'
        ? { type: 'watchCard', key: b.key }
        : b.do === 'hide'
          ? { type: 'hide', key: b.key }
          : { type: 'confirmMatch', key: b.key, yes: b.do === 'yes', name: b.data?.name, id: b.data?.id ?? null },
      { fromNotification: true }
    );
    if (res && !res.ok) openTarget('page', b.key); // např. plný limit: ukázat proč
  })
);

const STATE_TITLES = {
  open: 'přihlášení je otevřené',
  registered: 'přihlášeno ✅',
  probably: 'nejspíš přihlášeno ✅',
  failed: 'potřebuju tě',
  'needs-confirm': 'potřebuju tě',
  ambiguous: 'potřebuju tě',
  mismatch: 'potřebuju tě',
  confirm: 'potvrď akci',
  full: 'akce je plná',
  closed: 'přihlašování skončilo',
};

function setState(st, w, state, msg, shouldNotify = false) {
  const changed = w.state !== state;
  w.state = state;
  w.msg = msg;
  if (!changed) return;
  w.updatedAt = Date.now();
  if (!shouldNotify) return;
  const opts = { sticky: ['open', 'failed', 'needs-confirm', 'ambiguous', 'mismatch', 'confirm', 'registered', 'probably'].includes(state), key: w.key };
  if (state === 'open') opts.buttons = [{ title: 'Otevřít SIS', do: 'sis' }];
  if (state === 'confirm') {
    opts.click = 'page';
    const data = { name: w.confirmFor?.name, id: w.confirmFor?.id ?? null };
    opts.buttons = [
      { title: 'Ano, to je ona', do: 'yes', data },
      { title: 'Ne, není', do: 'no', data },
    ];
  }
  notify(st, STATE_TITLES[state] ?? state, `${w.label}: ${msg}`, opts);
}

// ---------- session a trezor ----------

function sessionExpired(st, why) {
  const s = st.session;
  if (s.status === 'ok' && s.since) {
    s.log.unshift({ start: s.since, end: Date.now(), minutes: Math.round((Date.now() - s.since) / 60_000), partial: s.partial });
    s.log = s.log.slice(0, 30);
  }
  if (s.status !== 'expired') {
    s.status = 'expired';
    s.since = Date.now();
  }
  if (!s.notified) {
    s.notified = true;
    notify(st, 'přihlas se do SIS', why, { sticky: true });
  }
}

function sessionOk(st) {
  const s = st.session;
  if (s.status !== 'ok') {
    s.partial = s.status === 'unknown'; // po startu nevíme, kdy přihlášení začalo
    s.status = 'ok';
    s.since = Date.now();
    s.notified = false;
  }
}

async function fetchText(url, opts = {}) {
  const res = await fetch(url, { credentials: 'include', cache: 'no-store', signal: AbortSignal.timeout(FETCH_TIMEOUT_MS), ...opts });
  return { res, html: await res.text() };
}

// Přihlášení do SIS z trezoru. Jeden pokus; po neúspěchu se trezor
// nepoužije, dokud ho uživatel znovu neodemkne (ochrana proti zablokování účtu).
async function vaultLogin(st, loginHtml, loginUrl) {
  const cred = await credentials(st);
  if (cred.state === 'none') return { ok: false, why: 'SIS tě odhlásil. Přihlas se v prohlížeči.' };
  if (cred.state === 'locked') {
    if (!st.vaultLockNotified) {
      st.vaultLockNotified = true;
      notify(st, 'odemkni trezor', 'SIS tě odhlásil a trezor je zamčený. Klikni a zadej hlavní heslo.', { sticky: true, click: 'page' });
    }
    return { ok: false, why: 'SIS tě odhlásil a trezor je zamčený. Odemkni ho, nebo se přihlas v prohlížeči.' };
  }
  if (st.vaultFailed) return { ok: false, why: 'Přihlášení z trezoru minule selhalo. Přihlas se ručně a trezor znovu odemkni.' };

  const fail = (why) => vaultFail(st, why);

  const form = parseLoginForm(loginHtml, loginUrl);
  if (!form) return fail('Nepoznám přihlašovací formulář SIS.');
  if (form.captcha) return fail('Přihlášení do SIS chce CAPTCHA.');
  let target = null;
  try {
    target = new URL(form.action);
  } catch {
    /* neplatná adresa = jinam */
  }
  if (target?.protocol !== 'https:' || target.host !== AUTH_HOST || form.method !== 'post') {
    return fail('Přihlašovací formulář míří jinam než na https://auth.vsem.cz.');
  }

  const body = new URLSearchParams(form.fields);
  body.set(form.userField, cred.username);
  body.set(form.passField, cred.password);
  // Po přihlášení vždy na seznam. Kdyby SIS uložil jako cíl ListSignIn,
  // přihlášení z trezoru by zároveň přihlásilo na akci a pak znovu.
  body.set('_target_path', SIS_LIST_URL);
  let res, html;
  try {
    ({ res, html } = await fetchText(form.action, { method: 'POST', body }));
  } catch (e) {
    return { ok: false, why: `Síťová chyba při přihlášení do SIS: ${e.message}` }; // síť není špatné heslo
  }
  if (looksLikeLogin(html, res.url)) return fail('SIS nepřijal jméno nebo heslo z trezoru.');
  return { ok: true };
}

// Po neúspěchu se trezor nepoužije, dokud ho uživatel znovu neodemkne.
function vaultFail(st, why) {
  st.vaultFailed = true;
  st.autoPaused = true;
  st.pauseReason = why;
  notify(st, 'přihlas se ručně', `${why} Automatické přihlašování jsem vypnul.`, { sticky: true });
  return { ok: false, why };
}

// GET seznamu; při přihlašovací stránce zkusí trezor a GET zopakuje.
async function getSisList(st) {
  let { res, html } = await fetchText(SIS_LIST_URL);
  if (!looksLikeLogin(html, res.url)) return { res, html };
  const login = await vaultLogin(st, html, res.url);
  if (!login.ok) return { expired: login.why };
  ({ res, html } = await fetchText(SIS_LIST_URL));
  if (looksLikeLogin(html, res.url)) return { expired: vaultFail(st, 'Ani po přihlášení z trezoru SIS seznam neukázal.').why };
  return { res, html, relogged: true };
}

// ---------- SIS ----------

async function checkSis(st) {
  st.sis.lastCheck = Date.now();
  let r;
  try {
    r = await getSisList(st);
  } catch (e) {
    return netError(st, e.message);
  }
  if (r.expired) {
    st.sis.errStreak = 0;
    return sessionExpired(st, r.expired);
  }
  if (!r.res.ok) return netError(st, `HTTP ${r.res.status}`);

  const parsed = parseSisList(r.html);
  if (!parsed.ok) {
    st.sis.errStreak = 0;
    return structureError(st, parsed.error);
  }

  st.sis.errStreak = 0;
  st.sis.error = null;
  st.sis.rows = parsed.rows;
  st.sis.source = 'own';
  sessionOk(st);
  for (const w of st.watches) await evaluateWatch(st, w, st.sis.rows); // signIn() řádky obnovuje
  return true;
}

function netError(st, msg) {
  st.sis.errStreak = (st.sis.errStreak || 0) + 1;
  st.sis.error = `SIS neodpovídá: ${msg}`;
  if (st.sis.errStreak === 3) notify(st, 'SIS neodpovídá', `Třikrát po sobě (${msg}). Zkouším to dál každých 5 minut.`);
}

function structureError(st, msg) {
  st.sis.error = msg;
  if (!st.autoPaused) {
    st.autoPaused = true;
    st.pauseReason = msg;
    notify(st, 'SIS se změnil', `${msg} Automatické přihlašování jsem vypnul. Zapni ho znovu, až to ověříš.`, { sticky: true, click: 'page' });
  }
}

async function evaluateWatch(st, w, rows) {
  if (['registered', 'needs-confirm', 'failed'].includes(w.state)) return;

  const matches = matchRows(w, rows);
  if (matches.length > 1) {
    return setState(st, w, 'ambiguous', `V SIS jsou na stejný čas ${matches.length} akce. Nic nedělám, přihlas se ručně.`, true);
  }
  if (matches.length === 0) {
    // Potvrzená akce se v SIS přejmenovala: na stejný čas je jediný jiný řádek. Zeptat se.
    if (w.confirmedName) {
      const rejected = new Set((w.rejectedNames ?? []).map((n) => n.toLowerCase()));
      const slotRows = rows.filter((r) => r.start?.date === w.date && r.start?.time === w.time && !rejected.has(r.name.toLowerCase()));
      if (slotRows.length === 1) return askConfirm(st, w, slotRows[0]);
    }
    const near = nearRows(w, rows);
    if (near.length) {
      const r = near[0];
      return setState(st, w, 'mismatch', `V SIS je „${r.name}“ v ${r.start.time ?? '?'}, ne v ${w.time}. Zkontroluj to ručně.`, true);
    }
    if (w.state === 'probably') return; // po přihlášení může řádek zmizet
    return setState(st, w, 'waiting', '');
  }

  const row = matches[0];
  Object.assign(w, {
    sisId: row.id,
    sisName: row.name,
    signinFrom: row.signinFrom,
    signinTo: row.signinTo,
    capacity: row.capacity,
  });

  if (row.signedIn) return setState(st, w, 'registered', 'SIS ukazuje, že jsi přihlášený.', true);
  if (w.state === 'signing') {
    // Service worker skončil uprostřed pokusu. Znovu nezkoušet.
    return row.canSignIn
      ? setState(st, w, 'failed', 'Pokus o přihlášení se přerušil. Přihlas se ručně, nebo klikni na Zkusit znovu.', true)
      : setState(st, w, 'probably', 'Tlačítko Přihlásit zmizelo, ověř to v SIS.', true);
  }
  if (w.state === 'probably') return;

  // Fáze 2: akce mimo Skill-Port/Hosté vybraná z webu potřebuje potvrdit řádek SIS.
  if (needsConfirm(w, row)) return askConfirm(st, w, row);

  if (!row.canSignIn) {
    const now = Date.now();
    if (row.signinTo && toMs(row.signinTo) < now) return setState(st, w, 'closed', 'Přihlašování už skončilo.', true);
    if (row.capacity !== null && row.capacity <= 0 && (!row.signinFrom || toMs(row.signinFrom) <= now)) {
      return setState(st, w, 'full', 'Akce je plná.', true);
    }
    return setState(st, w, 'listed', '');
  }

  // Přihlášení je otevřené. Dvě hlídání můžou ukazovat na stejný řádek: pokus jen jeden.
  const other = st.watches.find((x) => x !== w && x.sisId === row.id && (x.attempted || x.state === 'signing'));
  if (other) {
    w.attempted = true;
    return setState(st, w, 'probably', `Přihlašování už proběhlo u „${other.label}“. Ověř to v SIS.`, true);
  }
  if (mayAutoSign(w, row) && !st.autoPaused && !w.attempted) return signIn(st, w, row);

  const why = w.auto && st.autoPaused ? 'Automatické přihlašování je vypnuté, přihlas se ručně v SIS.' : 'Přihlas se v SIS.';
  return setState(st, w, 'open', why, true);
}

// Zeptat se na konkrétní řádek. Když se řádek změní, zeptat se znovu (nová notifikace).
function askConfirm(st, w, row) {
  const same = w.confirmFor && w.confirmFor.name === row.name && (w.confirmFor.id ?? null) === (row.id ?? null);
  if (w.state === 'confirm' && !same) w.state = 'waiting'; // vynutí novou notifikaci
  w.confirmFor = { name: row.name, id: row.id ?? null };
  Object.assign(w, { sisId: row.id, sisName: row.name });
  return setState(st, w, 'confirm', `V SIS jsem našel „${row.name}“ (${formatDt(row.start)}). Je to ona?`, true);
}

async function signIn(st, w, row) {
  if (isBlocked(st)) return; // vypnutá verze nikoho nepřihlašuje
  w.attempted = true;
  setState(st, w, 'signing', 'Přihlašuju…');
  await save(st); // zápis před požadavkem: po pádu se pokus nezopakuje

  let res, html;
  st.sis.lastCheck = Date.now(); // ListSignIn vrací seznam: další kontrola až za 30 s
  try {
    ({ res, html } = await fetchText(signInUrl(row.id)));
    if (looksLikeLogin(html, res.url)) {
      // Session spadla mezi seznamem a kliknutím: trezor, pak jeden nový pokus.
      const login = await vaultLogin(st, html, res.url);
      if (!login.ok) {
        sessionExpired(st, login.why);
        return setState(st, w, 'failed', `Přihlášení se nepovedlo: ${login.why}`, true);
      }
      ({ res, html } = await fetchText(signInUrl(row.id)));
    }
  } catch (e) {
    return setState(st, w, 'failed', `Síťová chyba při přihlášení: ${e.message}`, true);
  }

  const flash = extractFlash(html);
  st.responses.unshift({
    at: Date.now(),
    sisId: row.id,
    status: res.status,
    redirected: res.redirected,
    path: safePath(res.url),
    title: pageTitle(html),
    flash,
    hasForm: /<form\b/i.test(html),
  });
  st.responses = st.responses.slice(0, 10);

  if (looksLikeLogin(html, res.url)) {
    sessionExpired(st, 'SIS tě odhlásil uprostřed přihlašování na akci.');
    return setState(st, w, 'failed', 'Session vypršela těsně před přihlášením. Přihlas se do SIS a klikni na Zkusit znovu.', true);
  }

  let parsed = parseSisList(html);
  if (!parsed.ok) {
    if (/<form\b[\s\S]*?(ListSignIn|potvr|confirm)/i.test(html)) {
      return setState(st, w, 'needs-confirm', 'SIS ukázal potvrzovací formulář. Dokonči přihlášení ručně v SIS.', true);
    }
    try {
      st.sis.lastCheck = Date.now();
      parsed = parseSisList((await fetchText(SIS_LIST_URL)).html);
    } catch {
      /* vyhodnotí se níže */
    }
  }
  if (!parsed.ok) {
    return setState(st, w, 'failed', `Nepoznám odpověď SIS, zkontroluj to ručně.${flash ? ` SIS: ${flash}` : ''}`, true);
  }

  st.sis.rows = parsed.rows;
  const byId = parsed.rows.find((r) => r.id === row.id);
  const byMatch = matchRows(w, parsed.rows);
  const after = byId ?? (byMatch.length === 1 ? byMatch[0] : null);
  const note = flash ? ` SIS: ${flash}` : '';

  if (after?.signedIn) return setState(st, w, 'registered', `Přihlášeno.${note}`, true);
  if (!after || !after.canSignIn) return setState(st, w, 'probably', `Tlačítko Přihlásit zmizelo, ověř to v SIS.${note}`, true);
  return setState(st, w, 'failed', `Tlačítko Přihlásit tam pořád je.${note}`, true);
}

function safePath(url) {
  try {
    return new URL(url).pathname;
  } catch {
    return '';
  }
}

// ---------- harmonogram ----------

async function checkHarmo(st) {
  st.harmo.lastCheck = Date.now();
  let html;
  try {
    ({ html } = await fetchText(HARMONOGRAM_URL, { credentials: 'omit' }));
  } catch (e) {
    st.harmo.error = `Harmonogram se nenačetl: ${e.message}`;
    return;
  }
  const parsed = parseHarmonogram(html);
  if (!parsed.ok) {
    if (st.harmo.error !== parsed.error) notify(st, 'harmonogram se změnil', parsed.error, { click: 'harmo' });
    st.harmo.error = parsed.error;
    return;
  }
  st.harmo.error = null;
  st.harmo.rows = parsed.rows;
  st.harmo.source = 'own';
  return true;
}

// ---------- stav vydání (nová verze, vypnutí staré) ----------

async function checkRelease(st, now) {
  st.release.checkedAt = now;
  let ev;
  try {
    ev = evaluateRelease(await fetchStatus(), chrome.runtime.getManifest().version);
  } catch (e) {
    st.release.error = e.message; // bez spojení platí poslední známý stav
    return;
  }
  if (!ev) return;
  Object.assign(st.release, ev, { error: null });
  const mark = ev.state === 'ok' ? '' : `${ev.state}:${ev.reason ?? ''}:${ev.latest ?? ''}`;
  if (mark && st.release.notified !== mark) {
    if (ev.state === 'update') notify(st, `nová verze ${ev.latest}`, 'Stáhni ji a nahraď jí složku Simpolis. Klikni pro návod.', { click: 'release' });
    else notify(st, 'už nic nehlídám', ev.reason === 'ended' ? `Šimpoliš skončil. ${ev.message}`.trim() : `Tahle verze už nefunguje. Stáhni verzi ${ev.latest}.`, { click: 'release', sticky: true });
  }
  st.release.notified = mark;
}

// ---------- sdílený katalog ----------

// Místo vlastního dotazu převezme čerstvá sdílená data (jen když nic nehlídám).
function adoptSharedSis(st, shared, now) {
  st.sis.rows = adoptSisRows(shared.sis.rows, st.sis.rows, now);
  st.sis.lastCheck = now;
  st.sis.error = null;
  st.sis.source = 'shared';
  st.sis.sharedAt = shared.sis.fetchedAt;
}

function adoptSharedHarmo(st, shared, now) {
  st.harmo.rows = shared.harmo.rows;
  st.harmo.lastCheck = Date.parse(shared.harmo.fetchedAt); // stáří sdílené kopie, ne čas převzetí
  st.harmo.error = null;
  st.harmo.source = 'shared';
}

// Vlastní čerstvá data poslat ostatním. Selhání nic nerozbije, jen se zapíše do diagnostiky.
async function shareOwn(st, shared, own) {
  const sub = buildSubmission(st, shared, own);
  if (!sub) return;
  try {
    await submit(sub);
    if (sub.sis) st.share.sisAt = own.now;
    if (sub.harmo) st.share.harmoAt = own.now;
    st.share.sentAt = own.now;
    st.share.error = null;
  } catch (e) {
    st.share.error = `${new Date(own.now).toISOString()} ${e.message}`;
    if (sub.sis) st.share.sisAt = own.now; // nezkoušet při každé kontrole znovu
  }
}

// ---------- nové akce a otevřená přihlášení (nehlídané akce) ----------

// Fáze podle dohody: nehlídaná akce dostane nejvýš „nová“ a „otevřené“.
// Stejné datum a čas = stejná akce, i když se na webu a v SIS jmenuje jinak.
function announce(st) {
  const now = Date.now();
  const { web, sisOnly } = catalogOf(st);
  const cards = [...web, ...sisOnly];
  const watchedSlots = new Set(st.watches.map((w) => `${w.date}|${w.time ?? ''}`));
  const hiddenSlots = new Set(Object.values(st.hidden).map((h) => h.slot).filter(Boolean));
  const first = st.known === null;
  // První běh až s oběma zdroji, jinak by se druhý zdroj ohlásil celý jako „nové akce“.
  if (first && (!st.harmo.lastCheck || st.harmo.error || !st.sis.lastCheck || st.sis.error)) return;
  if (first) st.known = {};

  const fresh = [];
  const opened = [];
  for (const c of cards) {
    const k = st.known[c.slot];
    if (first) {
      st.known[c.slot] = { open: c.signinOpen };
      continue;
    }
    const skip = st.hidden[c.key] || hiddenSlots.has(c.slot) || watchedSlots.has(c.slot);
    if (!k) {
      st.known[c.slot] = { open: c.signinOpen };
      if (!skip) fresh.push(c);
    } else if (c.signinOpen && !k.open) {
      k.open = true;
      if (!skip) opened.push(c);
    }
  }

  if (fresh.length > BATCH_LIMIT) {
    notify(st, `${fresh.length} nových akcí`, fresh.map((c) => c.title).join(', '), { click: 'page' });
  } else {
    for (const c of fresh) {
      const where = c.source === 'sis' ? 'Nová akce v SIS' : 'Nová akce';
      notify(st, where.toLowerCase(), `${c.title}, ${formatWhen(c.date, c.time, now)}${c.online ? ', online' : ''}. ${signinText(c, now)}`, {
        click: 'page',
        key: c.key,
        sticky: c.signinOpen,
        buttons: [
          { title: 'Hlídat', do: 'watch' },
          { title: 'Nezajímá mě', do: 'hide' },
        ],
      });
    }
  }
  for (const c of opened) {
    notify(st, 'přihlášení je otevřené', `${c.title}, ${formatWhen(c.date, c.time, now)}. Přihlas se v SIS, pokud chceš.`, {
      key: c.key,
      buttons: [
        { title: 'Otevřít SIS', do: 'sis' },
        { title: 'Nezajímá mě', do: 'hide' },
      ],
    });
  }

  // Úklid: proběhlé sloty pryč.
  const today = new Date(now - 2 * 24 * 3600_000).toISOString().slice(0, 10);
  for (const slot of Object.keys(st.known)) if (slot.slice(0, 10) < today) delete st.known[slot];
}

// ---------- heartbeat, ikona, plánování ----------

function localDate(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function heartbeat(st) {
  const now = new Date();
  if (!st.heartbeat || now.getHours() < 8 || st.heartbeatDate === localDate(now)) return;
  st.heartbeatDate = localDate(now);
  const active = st.watches.filter(isActive).length;
  const sis = st.session.status === 'ok' ? 'SIS je přihlášený' : 'SIS tě odhlásil, přihlas se';
  notify(st, 'hlídám', `Hlídám akce: ${active}. ${sis}.${st.autoPaused ? ' Automatické přihlašování je vypnuté.' : ''}`, {
    click: 'page',
  });
}

async function updateIcon(st) {
  const level = iconLevel(st, { vaultLocked: await vaultLocked(st) });
  const prefix = level === 'idle' ? 'icons/' : `icons/${level}-`;
  await chrome.action.setIcon({ path: { 16: `${prefix}16.png`, 32: `${prefix}32.png`, 48: `${prefix}48.png`, 128: `${prefix}128.png` } });
  const open = st.watches.filter((w) => w.state === 'open').length;
  await chrome.action.setBadgeText({ text: open ? String(open) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
}

async function scheduleNext(st) {
  const plan = !st
    ? { when: Date.now() + RHYTHM.dayMax, reason: '' }
    : isBlocked(st)
      ? { when: Date.now() + STATUS_EVERY_MS, reason: 'vypnutá verze' } // jen občas zjistit, jestli se něco nezměnilo
      : planNext(st);
  await chrome.alarms.create(ALARM, { when: plan.when });
  if (st) await chrome.storage.local.set({ sis: { ...st.sis, nextCheck: plan.when, nextReason: plan.reason } });
}

async function tick({ manual = false } = {}) {
  let st;
  // Pojistka na začátku: kdyby Chrome service worker uprostřed ukončil,
  // řetěz kontrol se nepřetrhne. Na konci se nahradí skutečným plánem.
  await chrome.alarms.create(ALARM, { when: Date.now() + RHYTHM.dayMax });
  try {
    st = await load();
    const now = Date.now();
    if (now - (st.release.checkedAt || 0) >= (manual ? STATUS_MANUAL_GAP_MS : STATUS_EVERY_MS)) await checkRelease(st, now);
    if (isBlocked(st)) {
      await save(st);
      await updateIcon(st);
      return; // vypnutá verze: žádný dotaz do SIS, na web školy ani do sdíleného katalogu
    }
    const gap = manual ? MANUAL_GAP_MS : RHYTHM.minGap;
    const sisDue = now - (st.sis.lastCheck || 0) >= gap;
    const harmoDue = now - (st.harmo.lastCheck || 0) >= HARMO_EVERY_MS;
    // Bez složky ze sdíleného Disku (instalace ze ZIPu) se katalog stáhne z Apps Scriptu,
    // ale jen když ho opravdu můžu použít: harmonogram je na řadě, nebo nic nehlídám.
    const remote = harmoDue || (sisDue && !manual && st.known !== null && !st.watches.some(isActive));
    const shared = sisDue || harmoDue ? await readShared({ remote }) : null;
    let ownSis = false;
    let ownHarmo = false;
    if (sisDue) {
      if (canUseSharedSis(st, shared, { manual, now })) adoptSharedSis(st, shared, now);
      else ownSis = Boolean(await checkSis(st));
    }
    if (harmoDue) {
      if (canUseSharedHarmo(shared, HARMO_EVERY_MS, now)) adoptSharedHarmo(st, shared, now);
      else ownHarmo = Boolean(await checkHarmo(st));
    }
    if (ownSis || ownHarmo) await shareOwn(st, shared, { ownSis, ownHarmo, now });
    if (st.session.status === 'ok' || st.sis.source === 'shared') announce(st);
    heartbeat(st);
    await save(st);
    await updateIcon(st);
  } finally {
    await scheduleNext(st); // vždycky naplánovat další kontrolu, i po chybě
  }
}

// ---------- příkazy z popupu, Nastavení a notifikací ----------

async function handle(msg) {
  if (msg.type === 'checkNow') {
    await tick({ manual: true });
    return { ok: true };
  }
  const st = await load();
  const w = st.watches.find((x) => x.key === msg.key);
  let checkAfter = false;
  switch (msg.type) {
    case 'watchCard': {
      if (st.watches.some((x) => x.key === msg.key)) return { ok: true };
      const c = findCard(st, msg.key);
      if (!c) return { ok: false, error: 'Tuhle akci už nevidím.' };
      st.watches.push(newWatchFromCard(c, msg.auto ?? defaultAuto(c)));
      delete st.hidden[c.key];
      checkAfter = true;
      break;
    }
    case 'unwatch': // „Už mě nezajímá“: zrušit hlídání a schovat
      if (w) st.hidden[w.key] = { title: w.label, date: w.date, time: w.time, slot: `${w.date}|${w.time ?? ''}` };
      st.watches = st.watches.filter((x) => x.key !== msg.key);
      break;
    case 'hide': {
      const c = findCard(st, msg.key);
      st.hidden[msg.key] = { title: c?.title ?? msg.title ?? msg.key, date: c?.date, time: c?.time, slot: c?.slot };
      break;
    }
    case 'unhide':
      delete st.hidden[msg.key];
      break;
    case 'setAuto':
      if (!w) return { ok: false };
      w.auto = Boolean(msg.auto);
      if (!w.auto && w.state === 'confirm') setState(st, w, 'waiting', '');
      checkAfter = w.auto;
      break;
    case 'confirmMatch':
      if (!w || w.state !== 'confirm' || !w.confirmFor) return { ok: false, error: 'Tahle akce potvrzení nečeká.' };
      // Potvrzuje se řádek, který uživatel viděl. Když se mezitím v SIS změnil, nic.
      if (msg.name !== w.confirmFor.name || (msg.id ?? null) !== (w.confirmFor.id ?? null)) {
        return { ok: false, error: 'V SIS se mezitím akce změnila. Podívej se znovu a potvrď ji.' };
      }
      if (msg.yes) {
        w.confirmedName = w.confirmFor.name;
        w.confirmedId = w.confirmFor.id ?? null;
      } else w.rejectedNames = [...(w.rejectedNames ?? []), w.confirmFor.name];
      w.confirmFor = null;
      setState(st, w, 'waiting', '');
      checkAfter = true;
      break;
    case 'retry':
      if (!w) return { ok: false };
      w.attempted = false;
      setState(st, w, 'waiting', '');
      checkAfter = true;
      break;
    case 'resume':
      st.autoPaused = false;
      st.pauseReason = '';
      checkAfter = true;
      break;
    case 'vaultUnlocked': // klíč už leží v chrome.storage.session
      st.vaultFailed = false;
      st.vaultLockNotified = false;
      checkAfter = true;
      break;
    case 'setOption':
      if (!['heartbeat'].includes(msg.name)) return { ok: false, error: 'Neznámé nastavení.' };
      st[msg.name] = Boolean(msg.value);
      break;
    case 'noop':
      return { ok: true };
    default:
      return { ok: false, error: 'Neznámý příkaz.' };
  }
  // Uživatel chce vidět stav hned: vyhodnotit proti poslednímu seznamu ze SIS,
  // bez dalšího dotazu. Když je přihlášení otevřené a auto zapnuté, přihlásí se rovnou.
  if (checkAfter && !isBlocked(st) && st.session.status === 'ok' && st.sis.rows.length) {
    for (const x of st.watches) await evaluateWatch(st, x, st.sis.rows);
  }
  await save(st);
  await updateIcon(st);
  if (checkAfter) await tick({ manual: true }); // čerstvý SIS, pokud je poslední kontrola starší než 30 s
  else await scheduleNext(st);
  return { ok: true };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  serial(() => handle(msg)).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

// ---------- samoobnovení po výměně složky (ZIP nebo sdílená složka na Disku) ----------

const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

// Rozšíření je načtené ze složky Simpolis. Když v ní je nová verze (nový ZIP rozbalený na stejné místo)
// a všechny soubory už jsou celé (sedí otisky z version.json, který se nahrává poslední),
// Šimpoliš se obnoví sám. Bez version.json (vývojová složka) nedělá nic.
export async function checkSelfUpdate() {
  const loaded = chrome.runtime.getManifest().version;
  let rel;
  try {
    rel = await (await fetch(chrome.runtime.getURL('version.json'), { cache: 'no-store' })).json();
  } catch {
    return 'none';
  }
  if (!rel?.version || !rel.files || rel.version === loaded) return 'current';
  for (const [path, hash] of Object.entries(rel.files)) {
    try {
      const buf = await (await fetch(chrome.runtime.getURL(path), { cache: 'no-store' })).arrayBuffer();
      if (hex(await crypto.subtle.digest('SHA-256', buf)) !== hash) return 'syncing'; // synchronizace ještě běží
    } catch {
      return 'syncing';
    }
  }
  // Restart zamkne trezor (klíč je jen v paměti). S odemčeným trezorem proto jen,
  // když uživatel sedí u počítače a může ho hned odemknout.
  const { vault } = await chrome.storage.local.get('vault');
  const { vaultKey } = await chrome.storage.session.get('vaultKey');
  if (vault && vaultKey && (await chrome.idle?.queryState?.(5 * 60)) !== 'active') return 'waiting-user';
  await chrome.storage.local.set({ updatedFrom: loaded, updatedTo: rel.version, updatedAt: Date.now(), updateNotified: false });
  chrome.runtime.reload();
  return 'reloading';
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) serial(() => tick());
  if (a.name === WATCHDOG) {
    serial(async () => {
      await checkSelfUpdate();
      const t = await chrome.alarms.get(ALARM);
      if (!t || t.scheduledTime < Date.now() - 2 * 60_000) await tick();
    });
  }
});
// Jen když chybí: opakované vytvoření by periodu resetovalo a pojistka by nikdy nevystřelila.
chrome.alarms.get(WATCHDOG).then((a) => a || chrome.alarms.create(WATCHDOG, { periodInMinutes: 1 }));

// Po samoobnovení: když je trezor zamčený, hned o tom říct (uživatel je u počítače).
async function afterSelfUpdate() {
  const st = await load();
  if (st.updateNotified || st.updatedTo !== chrome.runtime.getManifest().version) return;
  st.updateNotified = true;
  if (await vaultLocked(st)) {
    notify(st, `aktualizováno na ${st.updatedTo}`, 'Po aktualizaci je trezor zamčený. Klikni a odemkni ho, ať tě můžu přihlásit do SIS.', { sticky: true, click: 'page' });
  }
  await save(st);
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details?.reason === 'install') chrome.runtime.openOptionsPage?.();
  serial(afterSelfUpdate);
  serial(() => tick({ manual: true }));
});
chrome.runtime.onStartup.addListener(() => serial(() => tick({ manual: true })));

// Pojistka: když se service worker probudí a žádný alarm neexistuje
// (např. se ztratil po pádu), naplánuj kontrolu hned.
serial(async () => {
  if (!(await chrome.alarms.get(ALARM))) await tick();
});
