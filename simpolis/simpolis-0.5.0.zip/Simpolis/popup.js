import { SIS_LIST_URL, HARMONOGRAM_URL } from './parser.js';
import { buildCatalog, statusItems, watchSentence, signinText, defaultAuto, formatWhen } from './model.js';
import { unlockVault } from './vault.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
if (params.get('page')) document.body.classList.add('page');
let focusKey = params.get('focus');
let showUnlock = false;
const autoChoice = new Map(); // volba „přihlásit mě automaticky“ přežije překreslení

function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c);
  return e;
}

async function send(msg) {
  const res = await chrome.runtime.sendMessage(msg);
  if (res && !res.ok && res.error) toast(res.error);
  return res;
}

function toast(text) {
  const t = el('div', { class: 'toast' }, text);
  document.body.append(t);
  setTimeout(() => t.remove(), 4000);
}

const openSis = () => chrome.tabs.create({ url: SIS_LIST_URL });
document.getElementById('harmo-link').href = HARMONOGRAM_URL;
document.getElementById('sis-link').href = SIS_LIST_URL;
// Potvrzení nese řádek, který uživatel právě vidí; když se v SIS mezitím změnil, service worker ho odmítne.
const confirmMatchW = (w, yes) => send({ type: 'confirmMatch', key: w.key, yes, name: w.confirmFor?.name, id: w.confirmFor?.id ?? null });
const confirmMatch = (st, key, yes) => {
  const w = (st.watches ?? []).find((x) => x.key === key);
  return w ? confirmMatchW(w, yes) : null;
};
const button = (label, onclick, cls = '') => el('button', { type: 'button', class: cls, onclick }, label);

function placeOf(c) {
  if (c.online) return c.place && c.source === 'web' ? c.place : 'online';
  return c.inBuilding ? 'v budově' : '';
}

function badge(c) {
  if (c.online) return el('span', { class: 'badge online' }, 'ONLINE');
  if (c.inBuilding) return el('span', { class: 'badge' }, 'v budově');
  return null;
}

function whenLine(c) {
  const place = placeOf(c);
  return el('p', { class: 'when' }, formatWhen(c.date, c.time), c.online && place ? ` · ${place}` : '');
}

// ---------- stav nahoře ----------

function unlockForm(st) {
  const input = el('input', { type: 'password', placeholder: 'hlavní heslo trezoru (ne heslo do SIS)', autocomplete: 'current-password' });
  const form = el('form', { class: 'inline' }, input, el('button', { type: 'submit', class: 'primary' }, 'Odemknout'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const keyB64 = await unlockVault(st.vault, input.value);
      await chrome.storage.session.set({ vaultKey: keyB64 });
      showUnlock = false;
      await send({ type: 'vaultUnlocked' });
      toast('Trezor je odemčený.');
    } catch (err) {
      toast(err.message);
    }
  });
  return form;
}

function actionsFor(item, st) {
  switch (item.kind) {
    case 'unlock':
      return [unlockForm(st), el('p', { class: 'small' }, 'Nebo se ', el('a', { href: SIS_LIST_URL, target: '_blank' }, 'přihlas do SIS'), ' sám.')];
    case 'login':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'resume':
      return [button('Zapnout znovu', () => send({ type: 'resume' }), 'primary')];
    case 'open':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'confirm':
      return [
        button('Ano, to je ona', () => confirmMatch(st, item.key, true), 'primary'),
        button('Ne, není', () => confirmMatch(st, item.key, false)),
      ];
    case 'release':
      return item.url ? [button('Otevřít návod', () => chrome.tabs.create({ url: item.url }), item.level === 'red' ? 'primary' : '')] : [];
    case 'need':
      return [button('Zkusit znovu', () => send({ type: 'retry', key: item.key })), button('Otevřít SIS', openSis)];
    default:
      return [];
  }
}

function renderStatus(st, vaultLocked) {
  const box = $('status');
  if (box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // rozepsané heslo
  const items = statusItems(st, { vaultLocked });
  const [top, ...rest] = items;
  box.replaceChildren(
    el('div', { class: `headline ${top.level}` },
      el('p', {}, top.text),
      el('div', { class: 'actions' }, actionsFor(top, st))),
    ...rest.map((i) =>
      el('div', { class: `secondary ${i.level}` }, el('p', {}, i.text), el('div', { class: 'actions' }, actionsFor(i, st))))
  );
  if (vaultLocked && top.kind !== 'unlock') {
    box.append(
      el('div', { class: 'secondary grey' },
        el('p', {}, '🔒 Trezor je zamčený. Když tě SIS odhlásí, sám tě zpátky nepřihlásím.'),
        showUnlock ? unlockForm(st) : button('Odemknout', () => ((showUnlock = true), refresh())))
    );
  }
}

function renderPulse(st) {
  const sis = st.sis ?? {};
  if (!sis.lastCheck) return ($('pulse').textContent = 'Ještě jsem nekontroloval.');
  const s = Math.round((Date.now() - sis.lastCheck) / 1000);
  const ago = s < 90 ? `před ${s} s` : s < 5400 ? `před ${Math.round(s / 60)} min` : `před ${Math.round(s / 3600)} h`;
  const next = sis.nextCheck ? new Date(sis.nextCheck).toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' }) : null;
  const src = sis.source === 'shared' ? ' ze sdíleného seznamu' : '';
  $('pulse').textContent = `Naposledy zkontrolováno ${ago}${src}${next ? ` · další kontrola v ${next}` : ''}.`;
}

// ---------- karty ----------

function watchCard(w, c) {
  const info = c ?? w;
  const s = watchSentence(w);
  const auto = el('label', { class: 'check' },
    el('input', { type: 'checkbox', checked: w.auto, onchange: (e) => send({ type: 'setAuto', key: w.key, auto: e.target.checked }) }),
    'přihlásit mě automaticky');
  const extra =
    w.state === 'open'
      ? [button('Otevřít SIS', openSis, 'primary')]
      : w.state === 'confirm'
        ? [button('Ano, to je ona', () => confirmMatchW(w, true), 'primary'), button('Ne, není', () => confirmMatchW(w, false))]
        : s.kind === 'need'
          ? [button('Zkusit znovu', () => send({ type: 'retry', key: w.key }))]
          : [];
  return el('li', { class: `card watched ${s.kind}`, 'data-key': w.key },
    el('div', { class: 'title' }, badge(info), el('span', {}, w.label)),
    whenLine(info),
    el('p', { class: `sentence ${s.kind}` }, s.text),
    extra.length ? el('div', { class: 'actions' }, extra) : null,
    el('div', { class: 'actions split' }, ['registered', 'probably'].includes(w.state) ? el('span') : auto,
      button('Už mě nezajímá', () => send({ type: 'unwatch', key: w.key }), 'quiet')));
}

function eventCard(c) {
  const auto = el('input', {
    type: 'checkbox',
    checked: autoChoice.get(c.key) ?? defaultAuto(c),
    onchange: (e) => autoChoice.set(c.key, e.target.checked),
  });
  return el('li', { class: 'card', 'data-key': c.key },
    el('div', { class: 'title' }, badge(c), el('span', {}, c.title)),
    whenLine(c),
    el('p', { class: `sentence ${c.signinOpen ? 'open' : 'wait'}` }, signinText(c)),
    el('div', { class: 'actions split' },
      el('div', { class: 'actions' },
        el('button', {
          type: 'button',
          class: 'primary',
          onclick: () => send({ type: 'watchCard', key: c.key, auto: auto.checked }),
        }, 'Hlídat'),
        el('label', { class: 'check' }, auto, 'přihlásit mě automaticky')),
      button('Nezajímá mě', () => send({ type: 'hide', key: c.key }), 'quiet')));
}

function render(st, vaultLocked) {
  const watches = st.watches ?? [];
  const hidden = st.hidden ?? {};
  const { web, sisOnly } = buildCatalog(st.harmo?.rows ?? [], st.sis?.rows ?? []);
  const byKey = new Map([...web, ...sisOnly].map((c) => [c.key, c]));
  const watched = new Set(watches.map((w) => w.key));
  const hiddenSlots = new Set(Object.values(hidden).map((h) => h.slot).filter(Boolean));
  const visible = (c) => !watched.has(c.key) && !hidden[c.key] && !hiddenSlots.has(c.slot);

  renderStatus(st, vaultLocked);
  renderPulse(st);

  $('watched-section').hidden = !watches.length;
  $('watched-title').textContent = `Hlídám (${watches.length})`;
  $('watched').replaceChildren(...watches.map((w) => watchCard(w, byKey.get(w.key))));


  const webCards = web.filter(visible);
  $('web').replaceChildren(...(webCards.length ? webCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, st.harmo?.lastCheck ? 'Žádné další akce s přihlášením.' : 'Načítám akce…')]));

  const sisCards = sisOnly.filter(visible);
  $('sis-count').textContent = `(${sisCards.length})`;
  $('sis').replaceChildren(...(sisCards.length ? sisCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, st.session?.status === 'ok' ? 'Nic dalšího.' : 'Nevím, SIS není přihlášený.')]));

  const hiddenEntries = Object.entries(hidden);
  $('hidden-section').hidden = !hiddenEntries.length;
  $('hidden-count').textContent = `(${hiddenEntries.length})`;
  $('hidden').replaceChildren(
    ...hiddenEntries.map(([key, h]) =>
      el('li', { class: 'card compact' },
        el('div', { class: 'title' }, el('span', {}, h.title)),
        el('div', { class: 'actions split' }, el('span', { class: 'when' }, h.date ? formatWhen(h.date, h.time) : ''), button('Vrátit', () => send({ type: 'unhide', key }))))
    )
  );

  if (focusKey) {
    const target = document.querySelector(`[data-key="${CSS.escape(focusKey)}"]`);
    if (target) {
      if (target.closest('details')) target.closest('details').open = true;
      target.classList.add('focus');
      target.scrollIntoView({ block: 'center' });
      focusKey = null;
    }
  }
}

async function refresh() {
  const [st, { vaultKey }] = await Promise.all([chrome.storage.local.get(null), chrome.storage.session.get('vaultKey')]);
  render(st, Boolean(st.vault) && !vaultKey);
}

chrome.storage.onChanged.addListener(() => refresh());
setInterval(() => refresh(), 15_000); // „před X s“ ať jde dopředu
refresh();
send({ type: 'checkNow' }); // čerstvý stav při otevření (service worker to omezí na 1× za 30 s)
