// Šimpoliš - parsery SIS a harmonogramu.
// Čisté funkce nad HTML textem: service worker v MV3 nemá DOMParser
// a stejný kód běží i v testech pod Node.

export const SIS_ORIGIN = 'https://sis.vsem.cz';
export const SIS_LIST_URL = `${SIS_ORIGIN}/sfsis/cs_CZ/EventsCalendarSigning?sort=fromTo&sort_type=asc`;
export const HARMONOGRAM_URL = 'https://www.vsem.cz/harmonogram-akci-vsem.html';
export const AUTH_HOST = 'auth.vsem.cz';

// Pevně v kódu, ne v nastavení: spolužáci to nemají obcházet.

export const signInUrl = (id) => `${SIS_ORIGIN}/sfsis/cs_CZ/EventsCalendarSigning/${Number(id)}/ListSignIn`;

// Auto-přihlášení je povolené jen pro akce bez studijních povinností.
// Rozhoduje název řádku v SIS, ne nastavení v popupu.
const AUTO_PREFIXES = ['skill port vsem', 'skillport vsem', 'hoste vsem'];

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '–', mdash: '—' };

export function decode(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') {
      const code = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}

export function textLines(html) {
  return decode(
    String(html ?? '')
      .replace(/<(script|style)\b[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|li)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .split('\n')
    .map((s) => s.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
}

export const toText = (html) => textLines(html).join(' ');

export function normalize(s) {
  return String(s ?? '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[-–—_:|/]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function isAutoAllowed(name) {
  const n = normalize(name);
  return AUTO_PREFIXES.some((p) => n.startsWith(p));
}

const pad = (n) => String(n).padStart(2, '0');
const ymd = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;

// "21.11.2026 17:00" -> { date: "2026-11-21", time: "17:00" }
export function parseSisDateTime(s) {
  const m = /(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/.exec(String(s ?? ''));
  if (!m) return null;
  return { date: ymd(m[3], m[2], m[1]), time: m[4] ? `${pad(m[4])}:${m[5]}` : null };
}

// Termín z harmonogramu: "14.12.2026, 17:00 hod.", "5.-7.2.2027", "28.11.-1.12.2026"
export function parseHarmonogramTermin(s) {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim();
  let m;
  let date = null;
  if ((m = /^\D*(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})/.exec(t))) date = ymd(m[3], m[2], m[1]);
  else if ((m = /(\d{1,2})\.\s*(\d{1,2})\.\s*-\s*\d{1,2}\.\s*\d{1,2}\.\s*(\d{4})/.exec(t))) date = ymd(m[3], m[2], m[1]);
  else if ((m = /(\d{1,2})\.\s*-\s*\d{1,2}\.\s*(\d{1,2})\.\s*(\d{4})/.exec(t))) date = ymd(m[3], m[2], m[1]);
  const tm = /(\d{1,2})[:.](\d{2})\s*hod/i.exec(t) || /(\d{1,2}):(\d{2})/.exec(t);
  return { date, time: tm ? `${pad(tm[1])}:${tm[2]}` : null, raw: t };
}

export function toMs(dt) {
  if (!dt?.date) return null;
  return new Date(`${dt.date}T${dt.time ?? '00:00'}:00`).getTime();
}

function cell(rowHtml, key) {
  const re = new RegExp(`<td[^>]*class="[^"]*\\bsf_admin_list_td_${key}\\b[^"]*"[^>]*>([\\s\\S]*?)</td>`, 'i');
  const m = re.exec(rowHtml);
  return m ? m[1] : null;
}

// Seznam akcí v SIS (EventsCalendarSigning).
// Vrací { ok: true, rows } nebo { ok: false, error } při změně struktury.
export function parseSisList(html) {
  const src = String(html ?? '');
  const markers = ['events_calendar_signing', 'sf_admin_list_th_name', 'sf_admin_list_th_fromTo'];
  const missing = markers.filter((k) => !src.includes(k));
  if (missing.length) return { ok: false, error: `Stránka SIS nemá očekávanou tabulku (chybí ${missing.join(', ')}).` };

  const rows = [];
  const rowRe = /<tr\b[^>]*class="[^"]*\bsf_admin_row\b[^"]*"[^>]*>([\s\S]*?)<\/tr>/gi;
  let m;
  while ((m = rowRe.exec(src))) {
    const r = m[1];
    const name = cell(r, 'name');
    const fromTo = cell(r, 'fromTo');
    const signin = cell(r, 'signin');
    if (name === null || fromTo === null || signin === null) {
      return { ok: false, error: 'Řádek v SIS nemá sloupce název / přihlášení / termín.' };
    }
    const actions = (/<ul[^>]*\bsf_admin_td_actions\b[^>]*>([\s\S]*?)<\/ul>/i.exec(r) || [])[1] ?? '';
    const inM = /href="([^"]*\/EventsCalendarSigning\/(\d+)\/ListSignIn)"/i.exec(actions);
    const outM = /href="[^"]*\/EventsCalendarSigning\/(\d+)\/ListSign(?:Out|Off)\w*"/i.exec(actions);
    const signedIn = Boolean(outM) || /Odhlásit/i.test(toText(actions));
    const [signinFrom, signinTo] = textLines(signin).map(parseSisDateTime);
    const [start, end] = textLines(fromTo).map(parseSisDateTime);
    const capText = toText(cell(r, 'fcap') ?? '');
    const row = {
      id: inM ? Number(inM[2]) : outM ? Number(outM[1]) : null,
      name: toText(name),
      descrip: toText(cell(r, 'descrip') ?? '').slice(0, 400),
      capacity: /^-?\d+$/.test(capText) ? Number(capText) : null,
      signinFrom: signinFrom ?? null,
      signinTo: signinTo ?? null,
      start: start ?? null,
      end: end ?? null,
      canSignIn: Boolean(inM),
      signedIn,
    };
    if (!row.name || !row.start?.date) {
      return { ok: false, error: 'Řádek v SIS nemá název nebo čitelný termín.' };
    }
    rows.push(row);
  }
  return { ok: true, rows };
}

// Přihlašovací stránka místo SIS = vypršelá session.
export function looksLikeLogin(html, finalUrl) {
  try {
    if (finalUrl && new URL(finalUrl).host === AUTH_HOST) return true;
  } catch {
    /* neplatná URL - rozhodne obsah */
  }
  const src = String(html ?? '');
  return /type="password"/i.test(src) && !/sf_admin_row/.test(src);
}

function attrs(tag) {
  const out = {};
  for (const m of tag.matchAll(/([\w:-]+)\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/g)) {
    out[m[1].toLowerCase()] = decode(m[3] ?? m[4] ?? m[5] ?? '');
  }
  return out;
}

// Přihlašovací formulář auth.vsem.cz (Symfony: POST /login_check,
// _username, _password, _csrf_token, _target_path).
// Vrací null, když stránka formulář s heslem nemá.
export function parseLoginForm(html, pageUrl) {
  const src = String(html ?? '');
  for (const fm of src.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)) {
    const body = fm[2];
    if (!/type\s*=\s*["']?password/i.test(body)) continue;
    const formAttrs = attrs(fm[1]);
    const fields = {};
    let userField = null;
    let passField = null;
    for (const im of body.matchAll(/<input\b[^>]*>/gi)) {
      const a = attrs(im[0]);
      const type = (a.type || 'text').toLowerCase();
      if (!a.name) continue;
      if (type === 'password') passField = a.name;
      else if (['text', 'email'].includes(type)) {
        if (!userField || /user|login|mail/i.test(a.name)) userField = a.name;
      } else if (type === 'hidden') fields[a.name] = a.value ?? '';
      else if (type === 'checkbox' && /remember/i.test(a.name)) fields[a.name] = a.value || 'on';
    }
    if (!userField || !passField) return null;
    let action;
    try {
      action = new URL(formAttrs.action || '', pageUrl).href;
    } catch {
      return null;
    }
    return {
      action,
      method: (formAttrs.method || 'get').toLowerCase(),
      fields,
      userField,
      passField,
      captcha: /captcha|recaptcha|turnstile|hcaptcha/i.test(src),
    };
  }
  return null;
}

// Hlášky Symfony adminu (notice / error) po akci.
export function extractFlash(html) {
  const out = [];
  const re = /<div[^>]*class="[^"]*\b(notice|error|flash[\w-]*|alert[\w-]*)\b[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;
  let m;
  while ((m = re.exec(String(html ?? ''))) && out.length < 5) {
    const t = toText(m[2]);
    if (t) out.push(t.slice(0, 300));
  }
  return out.join(' | ');
}

export function pageTitle(html) {
  return toText((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(String(html ?? '')) || [])[1] ?? '').slice(0, 120);
}

// Veřejný harmonogram akcí. Tabulka: typ | termín | přednášející | název | místo | přihlašování.
export function parseHarmonogram(html) {
  const src = String(html ?? '');
  const rows = [];
  let headerSeen = false;
  const trRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let m;
  while ((m = trRe.exec(src))) {
    const cells = [...m[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((c) => toText(c[1]));
    if (cells.length !== 6) continue;
    if (normalize(cells[0]) === 'typ akce') {
      headerSeen = true;
      continue;
    }
    const [type, terminRaw, speaker, title, place, signup] = cells;
    const termin = parseHarmonogramTermin(terminRaw);
    rows.push({
      key: `${termin.date ?? terminRaw}|${termin.time ?? ''}|${normalize(type)}`,
      type,
      date: termin.date,
      time: termin.time,
      terminRaw,
      speaker,
      title,
      place,
      signup,
      viaSis: /\bSIS\b/i.test(signup),
      online: /teams|online|on-line|zoom|webin/i.test(place),
    });
  }
  if (!headerSeen) return { ok: false, error: 'Harmonogram nemá tabulku s hlavičkou „Typ akce“.' };
  return { ok: true, rows };
}

// Hlídaná akce <-> řádek SIS: datum + čas začátku + začátek názvu.
export function matchWatch(watch, rows) {
  const prefix = normalize(watch.namePrefix);
  return rows.filter(
    (r) =>
      r.start?.date === watch.date &&
      (!watch.time || r.start?.time === watch.time) &&
      (!prefix || normalize(r.name).startsWith(prefix))
  );
}

// Stejné datum a název, jiný čas: nic nedělat, jen upozornit.
export function nearMatches(watch, rows) {
  if (!watch.namePrefix) return [];
  const prefix = normalize(watch.namePrefix);
  return rows.filter((r) => r.start?.date === watch.date && normalize(r.name).startsWith(prefix));
}

export function watchKey(w) {
  return `${w.date}|${w.time ?? ''}|${normalize(w.namePrefix || w.label)}`;
}
