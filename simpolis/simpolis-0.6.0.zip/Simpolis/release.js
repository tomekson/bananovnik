// Stav vydání: je nová verze, nebo tahle už nesmí běžet? Řídí ho status.json vedle návodu
// na webu Banánovníku (zapisuje tools/release.py). Šimpoliš si ho stahuje bez cookies.
//   { "latest": "0.5.0", "minVersion": "0.4.0", "ended": false, "message": "", "url": "https://…" }
export const STATUS_URL = 'https://tomekson.github.io/bananovnik/simpolis/status.json';
export const STATUS_EVERY_MS = 6 * 3600_000;
export const STATUS_MANUAL_GAP_MS = 10 * 60_000; // otevření popupu: nejvýš 1× za 10 min
const URL_PREFIX = 'https://tomekson.github.io/'; // odkaz ze status.json nesmí vést jinam

export function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return Math.sign(d);
  }
  return 0;
}

const isVersion = (v) => typeof v === 'string' && /^\d+(\.\d+){0,3}$/.test(v);

// status.json + vlastní verze -> { state: 'ok' | 'update' | 'blocked', ... }, nebo null (nečitelný soubor).
export function evaluateRelease(status, version) {
  if (!status || typeof status !== 'object') return null;
  const url = typeof status.url === 'string' && status.url.startsWith(URL_PREFIX) ? status.url : null;
  const message = typeof status.message === 'string' ? status.message.trim().slice(0, 300) : '';
  const latest = isVersion(status.latest) ? status.latest : null;
  if (status.ended === true) return { state: 'blocked', reason: 'ended', latest, message, url };
  if (isVersion(status.minVersion) && compareVersions(version, status.minVersion) < 0) {
    return { state: 'blocked', reason: 'old', latest: latest ?? status.minVersion, message, url };
  }
  if (latest && compareVersions(version, latest) < 0) return { state: 'update', latest, message, url };
  return { state: 'ok', latest, message: '', url };
}

export const isBlocked = (st) => st?.release?.state === 'blocked';

export async function fetchStatus() {
  const res = await fetch(STATUS_URL, { credentials: 'omit', cache: 'no-store', signal: AbortSignal.timeout(20_000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return JSON.parse(await res.text());
}
