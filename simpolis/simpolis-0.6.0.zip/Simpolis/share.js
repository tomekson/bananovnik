// Sdílený katalog akcí. Šimpoliše si přes Apps Script předávají veřejný seznam akcí,
// aby každý zvlášť nestahoval SIS a harmonogram. Hlavní kopie leží ve sdílené složce
// (data/katalog.json vedle rozšíření), odkud ji Šimpoliš čte bez dotazu na síť.
// Ven jde jen veřejná část řádků: žádný stav přihlášení, jméno ani přihlášení do SIS.
import { toMs } from './parser.js';
import { isActive } from './model.js';

export const SHARE_URL = 'https://script.google.com/macros/s/AKfycbzT5ZMigk3tY9SCWeU25_3sx2UgvuKroTGJu-e64Q4tXTeaHxMcQindi8YKIoEdrjng/exec';
export const SHARED_PATH = 'data/katalog.json';
export const SHARE_SCHEMA = 1;
export const SIS_SHARED_MS = 50 * 60_000; // sdílený SIS mladší než tohle stačí, když nic nehlídám
export const SIS_SUBMIT_GAP_MS = 50 * 60_000; // vlastní SIS posílám nejvýš jednou za 50 min
const SUBMIT_TIMEOUT_MS = 20_000;

const SIS_FIELDS = ['id', 'name', 'descrip', 'capacity', 'signinFrom', 'signinTo', 'start', 'end'];
const HARMO_FIELDS = ['key', 'type', 'date', 'time', 'terminRaw', 'speaker', 'title', 'place', 'signup', 'viaSis', 'online'];
const pick = (r, fields) => Object.fromEntries(fields.map((k) => [k, r?.[k] ?? null]));

export const publicSisRow = (r) => pick(r, SIS_FIELDS);
export const publicHarmoRow = (r) => pick(r, HARMO_FIELDS);

export function ageMs(iso, now) {
  const t = Date.parse(iso ?? '');
  return Number.isFinite(t) ? now - t : Infinity;
}

// Obsah data/katalog.json -> katalog, nebo null (chybí, poškozený, jiné schéma).
export function parseShared(text) {
  let k;
  try {
    k = JSON.parse(text);
  } catch {
    return null;
  }
  if (!k || k.schema !== SHARE_SCHEMA || !Array.isArray(k.harmo?.rows) || !Array.isArray(k.sis?.rows)) return null;
  return k;
}

// Smí kontrola místo vlastního dotazu do SIS použít sdílená data?
// Jen když nic nehlídám: hlídání a přihlášení na akci potřebují vlastní SIS.
export function canUseSharedSis(st, shared, { manual = false, now = Date.now() } = {}) {
  if (manual || st.known === null) return false; // ruční kontrola a první běh vždy vlastní
  if ((st.watches ?? []).some(isActive)) return false;
  if (!shared?.sis?.rows?.length) return false;
  return ageMs(shared.sis.fetchedAt, now) < SIS_SHARED_MS;
}

export function canUseSharedHarmo(shared, everyMs, now = Date.now()) {
  return Boolean(shared?.harmo?.rows?.length) && ageMs(shared.harmo.fetchedAt, now) < everyMs;
}

// Sdílené řádky SIS -> tvar parseSisList. Otevřené přihlášení se odvodí z okna a kapacity,
// „přihlášený“ se převezme z posledního vlastního seznamu (sdílená data ho nenesou).
export function adoptSisRows(rows, ownRows = [], now = Date.now()) {
  const signed = new Set(ownRows.filter((r) => r.signedIn && r.id != null).map((r) => r.id));
  return rows.map((r) => {
    const from = toMs(r.signinFrom);
    const to = toMs(r.signinTo);
    const full = r.capacity !== null && r.capacity !== undefined && r.capacity <= 0;
    const signedIn = signed.has(r.id);
    const open = from !== null && from <= now && (to === null || now <= to) && !full;
    return { ...publicSisRow(r), canSignIn: open && !signedIn && r.id != null, signedIn };
  });
}

// Co poslat: SIS jen když je sdílená kopie stará a sám jsem ho dlouho neposílal,
// harmonogram vždy, když jsem ho právě stáhl sám (stahuje se jen při staré sdílené kopii).
export function buildSubmission(st, shared, { ownSis, ownHarmo, now = Date.now() }) {
  const sub = { schema: SHARE_SCHEMA };
  const share = st.share ?? {};
  if (ownSis && ageMs(shared?.sis?.fetchedAt, now) >= SIS_SHARED_MS && now - (share.sisAt || 0) >= SIS_SUBMIT_GAP_MS) {
    sub.sis = { fetchedAt: new Date(st.sis.lastCheck).toISOString(), rows: st.sis.rows.map(publicSisRow) };
  }
  if (ownHarmo) sub.harmo = { fetchedAt: new Date(st.harmo.lastCheck).toISOString(), rows: st.harmo.rows.map(publicHarmoRow) };
  return sub.sis || sub.harmo ? sub : null;
}

// Nejdřív data/katalog.json vedle rozšíření (instalace ze sdílené složky na Disku),
// jinak s remote=true z Apps Scriptu (instalace ze ZIPu). Bez cookies.
export async function readShared({ remote = false } = {}) {
  try {
    const res = await fetch(chrome.runtime.getURL(SHARED_PATH), { cache: 'no-store' });
    const k = res.ok ? parseShared(await res.text()) : null;
    if (k) return k;
  } catch {
    /* složka bez data/ */
  }
  if (!remote) return null;
  try {
    const res = await fetch(SHARE_URL, { credentials: 'omit', cache: 'no-store', signal: AbortSignal.timeout(SUBMIT_TIMEOUT_MS) });
    return res.ok ? parseShared(await res.text()) : null;
  } catch {
    return null;
  }
}

// POST bez cookies: Apps Script nesmí vidět Google účet ani přihlášení do SIS.
export async function submit(sub) {
  const res = await fetch(SHARE_URL, {
    method: 'POST',
    credentials: 'omit',
    cache: 'no-store',
    headers: { 'Content-Type': 'text/plain' },
    body: JSON.stringify(sub),
    signal: AbortSignal.timeout(SUBMIT_TIMEOUT_MS),
  });
  const j = JSON.parse(await res.text());
  if (!j.ok) throw new Error(j.error || `HTTP ${res.status}`);
  return j;
}
