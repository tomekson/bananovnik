// Šimpoliš - trezor přihlašovacích údajů do SIS.
// AES-GCM-256, klíč z hlavního hesla přes PBKDF2-SHA-256 (600 000 iterací).
// chrome.storage.local drží jen sůl, IV a šifrový text.
// Odvozený klíč leží v chrome.storage.session: v paměti prohlížeče,
// nepřežije jeho restart, takže po startu Chromu je trezor zamčený.

export const ITERATIONS = 600_000;

const enc = new TextEncoder();
const dec = new TextDecoder();
const b64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const random = (n) => crypto.getRandomValues(new Uint8Array(n));

async function deriveKeyBytes(master, salt, iterations) {
  const base = await crypto.subtle.importKey('raw', enc.encode(master), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, base, 256);
  return new Uint8Array(bits);
}

const aesKey = (bytes) => crypto.subtle.importKey('raw', bytes, 'AES-GCM', false, ['encrypt', 'decrypt']);

export async function createVault(master, username, password, iterations = ITERATIONS) {
  if (!master || master.length < 8) throw new Error('Hlavní heslo musí mít aspoň 8 znaků.');
  if (!username || !password) throw new Error('Vyplň jméno i heslo do SIS.');
  const salt = random(16);
  const iv = random(12);
  const keyBytes = await deriveKeyBytes(master, salt, iterations);
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    await aesKey(keyBytes),
    enc.encode(JSON.stringify({ u: username, p: password }))
  );
  return {
    vault: { v: 1, iterations, salt: b64(salt), iv: b64(iv), ct: b64(ct), createdAt: Date.now() },
    keyB64: b64(keyBytes),
  };
}

// Ověří hlavní heslo a vrátí klíč pro chrome.storage.session.
export async function unlockVault(vault, master) {
  const keyBytes = await deriveKeyBytes(master, unb64(vault.salt), vault.iterations);
  const keyB64 = b64(keyBytes);
  await decryptVault(vault, keyB64); // vyhodí chybu při špatném hesle
  return keyB64;
}

export async function decryptVault(vault, keyB64) {
  try {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(vault.iv) }, await aesKey(unb64(keyB64)), unb64(vault.ct));
    const { u, p } = JSON.parse(dec.decode(pt));
    return { username: u, password: p };
  } catch {
    throw new Error('Špatné hlavní heslo.');
  }
}
