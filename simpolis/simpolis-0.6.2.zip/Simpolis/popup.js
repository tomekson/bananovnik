import { SIS_LIST_URL, HARMONOGRAM_URL } from './parser.js';
import { buildCatalog, statusItems, checkSummary, iconLevel, isActive, watchSentence, signinText, formatWhen } from './model.js';
import { unlockVault } from './vault.js';
import { calendarEvent, googleUrl, outlookUrl, icsFile } from './calendar.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
if (params.get('page')) document.body.classList.add('page');
let focusKey = params.get('focus');
let showUnlock = false;

// Zaškrtávátko automatického přihlášení + (i) s vysvětlením ve sdíleném popoveru (popup.html).
function autoCheck(checked, onchange) {
  const input = el('input', { type: 'checkbox', checked, onchange: (e) => onchange(e.target.checked) });
  const info = el('button', { type: 'button', class: 'info', popovertarget: 'auto-info', 'aria-label': 'Co dělá auto-přihlášení' }, 'i');
  return { input, label: el('span', { class: 'check' }, el('label', { class: 'check' }, input, 'Auto-přihlášení na akci'), info) };
}

function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c);
  return e;
}

async function send(msg) {
  const res = await chrome.runtime.sendMessage(msg);
  if (res && !res.ok && res.error) toast(res.error);
  return res;
}

function toast(text) {
  const t = el('div', { class: 'toast' }, text);
  document.body.append(t);
  setTimeout(() => t.remove(), 4000);
}

const openSis = () => chrome.tabs.create({ url: SIS_LIST_URL });
document.getElementById('harmo-link').href = HARMONOGRAM_URL;
document.getElementById('sis-link').href = SIS_LIST_URL;
// Potvrzení nese řádek, který uživatel právě vidí; když se v SIS mezitím změnil, service worker ho odmítne.
const confirmMatchW = (w, yes) => send({ type: 'confirmMatch', key: w.key, yes, name: w.confirmFor?.name, id: w.confirmFor?.id ?? null });
const confirmMatch = (st, key, yes) => {
  const w = (st.watches ?? []).find((x) => x.key === key);
  return w ? confirmMatchW(w, yes) : null;
};
const button = (label, onclick, cls = '') => el('button', { type: 'button', class: cls, onclick }, label);

function placeOf(c) {
  if (c.online) return c.place && c.source === 'web' ? c.place : 'online';
  return c.inBuilding ? 'osobně' : '';
}

// Časový sloupec karty jako v hlídkovém záznamu: den, hodina, rok jen když není letošní.
const DAYS = ['ne', 'po', 'út', 'st', 'čt', 'pá', 'so'];
function stamp(c) {
  if (!c.date) return el('div', { class: 'stamp' }, el('span', { class: 'day' }, 'termín'), el('span', { class: 'day' }, 'neznámý'));
  const d = new Date(`${c.date}T12:00:00`);
  const year = d.getFullYear() !== new Date().getFullYear() ? String(d.getFullYear()) : null;
  return el('div', { class: 'stamp' },
    el('span', { class: 'day' }, `${DAYS[d.getDay()]} ${d.getDate()}. ${d.getMonth() + 1}.`),
    c.time ? el('span', { class: 'time' }, c.time) : null,
    year ? el('span', { class: 'day' }, year) : null,
    el('button', { type: 'button', class: 'cal-link', onclick: () => openCalendar(c) }, 'Přidat do kalendáře'));
}

// Testovací funkce: nabídka kalendářů ve sdíleném popoveru (popup.html).
function openCalendar(c) {
  const ev = calendarEvent(c);
  if (!ev) return;
  const ics = () => {
    const url = URL.createObjectURL(new Blob([icsFile(ev)], { type: 'text/calendar' }));
    const name = ev.title.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').toLowerCase();
    el('a', { href: url, download: `${name || 'akce'}.ics` }).click();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  };
  $('cal-what').textContent = `${ev.title}, ${formatWhen(c.date, c.time)}`;
  $('cal-links').replaceChildren(
    el('a', { class: 'cal-option', href: googleUrl(ev), target: '_blank', rel: 'noopener' }, 'Google Kalendář'),
    el('a', { class: 'cal-option', href: outlookUrl(ev), target: '_blank', rel: 'noopener' }, 'Outlook'),
    el('button', { type: 'button', class: 'cal-option', onclick: ics }, 'Soubor .ics (Apple Kalendář a ostatní)'));
  $('cal-menu').showPopover();
}

// Pod názvem jedna řádka: kde (online / osobně) a v jakém stavu akce je. Stav říká text, ne barevný pruh.
function cardBody(c, title, kind, text, ...rest) {
  const place = placeOf(c);
  return [stamp(c), el('div', { class: 'body' },
    el('p', { class: 'title' }, title),
    el('p', { class: `sentence ${kind}` },
      place ? el('span', { class: `place${c.online ? ' online' : ''}` }, place === 'online' || !c.online ? place : `online · ${place}`) : null,
      place ? ' · ' : null,
      text),
    ...rest)];
}

// ---------- stav nahoře ----------

function unlockForm(st) {
  const input = el('input', { type: 'password', placeholder: 'heslo Trezoru', autocomplete: 'current-password' });
  const form = el('form', { class: 'inline' }, input, el('button', { type: 'submit', class: 'primary' }, 'Odemknout'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const keyB64 = await unlockVault(st.vault, input.value);
      // Pole pustit hned: dokud je v něm kurzor, stav nahoře se nepřekresluje (ochrana rozepsaného hesla).
      input.value = '';
      input.blur();
      showUnlock = false;
      await chrome.storage.session.set({ vaultKey: keyB64 });
      await refresh(); // hned „Šimpoliš se přihlašuje do SIS…“
      await send({ type: 'vaultUnlocked' });
      await refresh();
    } catch (err) {
      toast(err.message);
    }
  });
  return form;
}

function actionsFor(item, st) {
  switch (item.kind) {
    case 'unlock':
      return [unlockForm(st)];
    case 'login':
    case 'detour':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'resume':
      return [button('Zapnout znovu', () => send({ type: 'resume' }), 'primary')];
    case 'open':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'confirm':
      return [
        button('Ano, to je ona', () => confirmMatch(st, item.key, true), 'primary'),
        button('Ne, není', () => confirmMatch(st, item.key, false)),
      ];
    case 'release':
      return item.url ? [button('Otevřít návod', () => chrome.tabs.create({ url: item.url }), item.level === 'red' ? 'primary' : '')] : [];
    case 'need':
      return [button('Zkusit znovu', () => send({ type: 'retry', key: item.key })), button('Otevřít SIS', openSis)];
    default:
      return [];
  }
}

// Pravidlo ticha: když je vše v pořádku, jeden tichý řádek. Výrazný blok jen tehdy,
// když něco blokuje nebo čeká na rozhodnutí. Modré věci k akcím ukazují karty níže.
function renderStatus(st, vaultLocked) {
  const box = $('status');
  if (box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // rozepsané heslo
  const items = statusItems(st, { vaultLocked });
  const [top] = items;
  if (top.level === 'green') {
    const ok = items.find((i) => ['progress', 'ok', 'idle'].includes(i.kind)) ?? top;
    box.replaceChildren(el('p', { class: `ok-line ${ok.kind}` }, ok.text));
  } else {
    const rest = items.slice(1).filter((i) => i.level === 'red' || i.kind === 'release');
    const progress = items.find((i) => i.kind === 'progress');
    box.replaceChildren(
      el('div', { class: `headline ${top.level} ${top.kind}` }, el('p', {}, top.text), el('div', { class: 'actions' }, actionsFor(top, st))),
      ...rest.map((i) => el('div', { class: `secondary ${i.level}` }, el('p', {}, i.text), el('div', { class: 'actions' }, actionsFor(i, st)))),
      ...(progress ? [el('p', { class: 'ok-line progress below' }, progress.text)] : [])
    );
  }
  // Zamčený trezor vadí jen tehdy, když má Šimpoliš někoho přihlásit sám.
  const autoWaiting = (st.watches ?? []).some((w) => isActive(w) && w.auto);
  if (vaultLocked && autoWaiting && top.kind !== 'unlock') {
    box.append(
      el('div', { class: 'secondary grey' },
        el('p', {}, '🔒 Trezor je zamčený. Když tě SIS odhlásí, Šimpoliš tě na akci nepřihlásí.'),
        showUnlock ? unlockForm(st) : el('div', { class: 'actions' }, button('Odemknout', () => ((showUnlock = true), refresh()))))
    );
  }
}

// Kdy Šimpoliš kontroloval, ukáže jen tehdy, když to něco znamená: SIS opakovaně
// neodpovídá, nebo poslední kontrola je podezřele stará.
function renderPulse(st) {
  const sis = st.sis ?? {};
  const p = $('pulse');
  let text = '';
  if ((sis.errStreak ?? 0) >= 2 && sis.error) text = sis.error;
  else if (sis.lastCheck && Date.now() - sis.lastCheck > 75 * 60_000) {
    text = `Naposledy zkontrolováno před ${Math.round((Date.now() - sis.lastCheck) / 3_600_000)} h`;
  }
  p.textContent = text;
  p.hidden = !text;
}

// ---------- karty ----------

function watchCard(w, c) {
  const info = c ?? w;
  const s = watchSentence(w);
  const auto = autoCheck(w.auto, (on) => send({ type: 'setAuto', key: w.key, auto: on })).label;
  const extra =
    w.state === 'open'
      ? [button('Otevřít SIS', openSis, 'primary')]
      : w.state === 'confirm'
        ? [button('Ano, to je ona', () => confirmMatchW(w, true), 'primary'), button('Ne, není', () => confirmMatchW(w, false))]
        : s.kind === 'need'
          ? [button('Zkusit znovu', () => send({ type: 'retry', key: w.key }))]
          : [];
  return el('li', { class: `card watched ${s.kind}`, 'data-key': w.key }, ...cardBody(info, w.label, s.kind, s.text,
    extra.length ? el('div', { class: 'actions' }, extra) : null,
    el('div', { class: 'actions split' }, ['registered', 'probably'].includes(w.state) ? el('span') : auto,
      el('div', { class: 'actions' },
        button('Nehlídat', () => send({ type: 'stopWatch', key: w.key }), 'quiet'),
        button('Akci vynechám', () => send({ type: 'unwatch', key: w.key }), 'quiet')))));
}

// Katalog: jen Hlídat a Akci vynechám. Auto-přihlášení se ukáže až u hlídané akce,
// kde opravdu platí (předvolba podle typu akce, online z harmonogramu zapnuté).
function eventCard(c) {
  return el('li', { class: 'card', 'data-key': c.key }, ...cardBody(c, c.title, c.signinOpen ? 'open' : 'wait', signinText(c),
    el('div', { class: 'actions split' }, el('span'),
      el('div', { class: 'actions' },
        button('Hlídat', () => send({ type: 'watchCard', key: c.key }), 'primary'),
        button('Akci vynechám', () => send({ type: 'hide', key: c.key }), 'quiet')))));
}

function render(st, vaultLocked) {
  const watches = st.watches ?? [];
  const hidden = st.hidden ?? {};
  const { web, sisOnly } = buildCatalog(st.harmo?.rows ?? [], st.sis?.rows ?? []);
  const byKey = new Map([...web, ...sisOnly].map((c) => [c.key, c]));
  const watched = new Set(watches.map((w) => w.key));
  const hiddenSlots = new Set(Object.values(hidden).map((h) => h.slot).filter(Boolean));
  const visible = (c) => !watched.has(c.key) && !hidden[c.key] && !hiddenSlots.has(c.slot);

  renderStatus(st, vaultLocked);
  renderPulse(st);
  // Stejná ikona jako v liště Chromu, ať je stav vidět i ve velkém.
  const level = iconLevel(st, { vaultLocked });
  $('logo').src = level === 'idle' ? 'icons/48.png' : `icons/${level}-48.png`;

  $('watched-section').hidden = !watches.length;
  // Bez přihlášeného SIS Šimpoliš akce nevidí: nadpis nesmí tvrdit, že hlídá.
  const stopped = st.session?.status === 'expired' || st.release?.state === 'blocked' || Boolean(st.sis?.detour);
  $('watched-title').textContent = stopped ? 'Hlídání je pozastavené' : `Šimpoliš hlídá (${watches.filter(isActive).length})`;
  // Co udělat, aby hlídání zase běželo. Jedna věta, stejná cesta jako výzva nahoře.
  const sisLink = () => el('a', { href: SIS_LIST_URL, target: '_blank' }, 'přihlásíš do SISu');
  const resume = !stopped
    ? []
    : st.release?.state === 'blocked'
      ? ['Hlídání se obnoví po stažení nové verze Šimpoliše']
      : st.sis?.detour && st.session?.status !== 'expired'
        ? ['Hlídání se obnoví, až v SISu vyřídíš, co po tobě chce']
      : vaultLocked && !st.vaultFailed
        ? ['Hlídání se obnoví, až odemkneš Trezor nebo se ', sisLink()]
        : st.vault && !st.vaultFailed
          ? ['Hlídání se obnoví hned po přihlášení do SISu']
          : st.vault
            ? ['Hlídání se obnoví, až se přihlásíš do SISu'] // Trezor selhal: cestu do SIS ukazuje červený blok
            : ['Hlídání se obnoví, až se přihlásíš do SISu. Aby se Šimpoliš přihlašoval sám, ',
                el('a', { href: 'options.html#vault-section', target: '_blank' }, 'založ si Trezor'), '.'];
  $('watched-resume').replaceChildren(...resume);
  $('watched-resume').hidden = !resume.length;
  $('watched-section').classList.toggle('stopped', stopped); // šachovnice zešedne: hlídka nejede
  // Chronologicky: nejbližší nahoře, akce bez termínu na konci.
  const when = (w) => (w.date ? `${w.date} ${w.time ?? '99:99'}` : '9999');
  const ordered = [...watches].sort((a, b) => when(a).localeCompare(when(b)));
  $('watched').replaceChildren(...ordered.map((w) => watchCard(w, byKey.get(w.key))));


  const webCards = web.filter(visible);
  $('web').replaceChildren(...(webCards.length ? webCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, !st.harmo?.lastCheck ? 'Šimpoliš načítá akce…' : web.length ? 'Všechny akce z harmonogramu už hlídáš nebo jsou skryté' : 'Harmonogram školy teď nemá žádnou akci s přihlašováním')]));

  const sisCards = sisOnly.filter(visible);
  $('sis-count').textContent = `(${sisCards.length})`;
  $('sis').replaceChildren(...(sisCards.length ? sisCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, st.session?.status !== 'ok' ? 'SIS není přihlášený' : sisOnly.length ? 'Všechny další akce ze SIS už hlídáš nebo jsou skryté' : 'V SIS teď není žádná další akce')]));

  const hiddenEntries = Object.entries(hidden);
  $('hidden-section').hidden = !hiddenEntries.length;
  $('hidden-count').textContent = `(${hiddenEntries.length})`;
  $('hidden').replaceChildren(
    ...hiddenEntries.map(([key, h]) =>
      el('li', { class: 'card compact' },
        el('div', { class: 'title' }, el('span', {}, h.title)),
        el('div', { class: 'actions split' }, el('span', { class: 'when' }, h.date ? formatWhen(h.date, h.time) : ''), button('Vrátit', () => send({ type: 'unhide', key }))))
    )
  );

  if (focusKey) {
    const target = document.querySelector(`[data-key="${CSS.escape(focusKey)}"]`);
    if (target) {
      if (target.closest('details')) target.closest('details').open = true;
      target.classList.add('focus');
      target.scrollIntoView({ block: 'center' });
      focusKey = null;
    }
  }
}

async function refresh() {
  const [st, { vaultKey }] = await Promise.all([chrome.storage.local.get(null), chrome.storage.session.get('vaultKey')]);
  const vaultLocked = Boolean(st.vault) && !vaultKey;
  render(st, vaultLocked);
  // Výsledek kontroly drží krok se stavem (třeba po odemčení trezoru).
  const out = $('check-result');
  if (!out.hidden) out.replaceChildren(...checkSummary(st, { vaultLocked }).map((p) => el('span', { class: p.startsWith('❌') ? 'red' : '' }, p)));
}

// Tlačítko Ověřit přihlášení: čerstvý dotaz do SIS a jednořádkový přehled, co běží a co ne.
async function checkNow() {
  const btn = $('check-now');
  const out = $('check-result');
  btn.disabled = true;
  btn.classList.add('busy');
  try {
    await send({ type: 'checkNow', force: true });
    out.hidden = false;
    await refresh();
  } finally {
    btn.disabled = false;
    btn.classList.remove('busy');
  }
}
$('check-now').addEventListener('click', checkNow);

chrome.storage.onChanged.addListener(() => refresh());
setInterval(() => refresh(), 15_000); // „před X s“ ať jde dopředu
refresh();
send({ type: 'checkNow' }); // čerstvý stav při otevření (service worker to omezí na 1× za 30 s)
