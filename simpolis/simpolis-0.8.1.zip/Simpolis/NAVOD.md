# Šimpoliš (beta): návod

Šimpoliš je šimpanz policajt 🐵👮, rozšíření pro Chrome na počítači (Mac i Windows). Funguje i v Edge a Brave. **Na mobilu nefunguje.**

Návod je i na webu: [tomekson.github.io/bananovnik/simpolis](https://tomekson.github.io/bananovnik/simpolis/).

- **Hlídá akce, které si vybereš.** Jakmile je možné se přihlásit, dá ti vědět.
- **Umí tě na akci přihlásit automaticky.** Potřebuje k tomu spuštěný Chrome, počítač, který nespí, a povolený Trezor. Auto-přihlášení zapne spolu s hlídáním, vypnout si ho můžeš.
- **Upozorní tě na nové akce** a na čas, kdy se otevře přihlášení. Akce, které tě nezajímají, schováš jedním kliknutím.
- **Osobní data nesdílí.** Heslo a přihlášení do SIS neopustí tvůj počítač. Hlídané akce si Chrome synchronizuje jen přes tvůj účet Google.

## Instalace

Šimpoliš není v Chrome Web Store, instaluje se ze ZIPu.

**Krok 1: stáhni ZIP.** Tlačítko **Stáhnout Šimpoliše** je nahoře na stránce s návodem. Soubor se uloží do složky **Stažené soubory**.

**Krok 2: rozbal ho.** Na Macu na stažený soubor dvakrát klikni. Ve Windows na něj klikni pravým tlačítkem a zvol **Extrahovat vše**, pak **Extrahovat**.

**Krok 3: přesuň rozbalenou složku `Simpolis` do Dokumentů.** Chrome si Šimpoliše načítá odtud, takže ji nepřejmenovávej ani nemaž. Přesun do iCloud Drive popisuje část Víc Maců.

**Krok 4: otevři v Chromu stránku Rozšíření.** Napiš do adresního řádku `chrome://extensions` a stiskni Enter.

**Krok 5: zapni Režim pro vývojáře.** Přepínač je vpravo nahoře.

**Krok 6: klikni na Načíst rozbalené** a vyber složku `Simpolis` v Dokumentech.

![Stránka Rozšíření v Chromu na počítači: 5 je přepínač Režim pro vývojáře vpravo nahoře, 6 je tlačítko Načíst rozbalené vlevo](navod/chrome-stranka-rozsireni.png)

**Načteno:** v seznamu rozšíření uvidíš kartu Šimpoliše se zapnutým modrým přepínačem.

![Karta rozšíření Šimpoliš (beta) se zapnutým přepínačem](navod/chrome-3-nacteno.png)

**Krok 7: klikni na dílek skládačky** vpravo od adresního řádku.

**Krok 8: klikni na špendlík u Šimpoliše.** Šimpanz pak zůstane v liště po ruce.

![Lišta Chromu: 7 je dílek skládačky vpravo od adresního řádku, 8 je špendlík u Šimpoliše](navod/chrome-4-pripnout.svg)

Po instalaci se otevře Nastavení s krátkým úvodem.

## Aktualizace

**Kdy aktualizovat, ti Šimpoliš řekne.** Drobné úpravy vycházejí potichu. Upozorní jen na verzi, která za to stojí: v okně šimpanze se objeví modrý pruh a přijde notifikace.

1. **Stáhni nový ZIP** tlačítkem nahoře na stránce a rozbal ho jako při instalaci.
2. **Přetáhni novou složku `Simpolis` do Dokumentů** a zvol **Nahradit**.
3. **Počkej minutu.** Šimpoliš si novou verzi načte automaticky. Kdyby ne, klikni na stránce Rozšíření u Šimpoliše na kruhovou šipku.
4. **Povol Trezor**, pokud ho používáš. Po aktualizaci je vypnutý.

**Hlídané akce i Trezor zůstanou.** Rozšíření kvůli aktualizaci neodebírej, to by smazalo všechno.

**Výjimka: přechod na verzi 0.8.0.** Šimpoliš od ní má na všech počítačích stejné ID. Chrome ho proto jednou načte jako nové rozšíření a předchozí nastavení zmizí:

- **Hlídané akce** zvol znovu tlačítkem **Hlídat**, u každé zkontroluj auto-přihlášení.
- **Skryté akce** znovu schovej tlačítkem **Akci vynechám**.
- **Trezor** založ znovu v Nastavení. Heslo do SIS i hlavní heslo zadáš jako poprvé.
- **Stará karta:** kdyby v `chrome://extensions` zůstala druhá karta Šimpoliše s chybou, odeber ji.

**Když neaktualizuješ,** stará verze hlídá dál. Jen při vážné chybě nebo po konci projektu ji autor na dálku vypne: přestane hlídat a v okně šimpanze uvidíš červené upozornění s důvodem.

**Kterou verzi máš,** vidíš v hlavičce okna Šimpoliše vedle (beta).

## Notifikace

Notifikace jsou nepovinné, ale doporučené. Šimpoliš funguje i bez nich:

- **Ikona šimpanze v liště** ukáže, co se děje. Modrá s číslem znamená otevřené přihlášení, červená, že je potřeba tvůj krok.
- **Automatické přihlášení** funguje i bez notifikací.
- **S notifikacemi** se o otevřeném přihlášení dozvíš hned, i když se na lištu zrovna nedíváš.

### Mac

1. **Otevři** Nastavení systému, pak **Oznámení**, pak **Google Chrome**.
2. **Zapni** Povolit oznámení.
3. **Nastav** styl na **Upozornění** (v novějším macOS **Trvalé**). Jinak notifikace za pár sekund zmizí.

### Windows

1. **Otevři** Nastavení, pak **Systém**, pak **Oznámení**.
2. **Zapni** oznámení pro **Google Chrome**.
3. **Vypni** režim **Nerušit**, nebo do výjimek přidej Google Chrome.

## Víc Maců

Hlídané a skryté akce se sdílí mezi počítači, kde jsi v Chromu přihlášený stejným účtem Google a máš zapnutou synchronizaci. Trezor se nesdílí: na každém počítači ho založ zvlášť.

Složku `Simpolis` můžeš dát do iCloud Drive. Nová verze, kterou do ní nahraješ, se pak dostane na všechny tvoje Macy. Když máš v iCloudu zapnuté **Plochu a Dokumenty**, složka `Dokumenty/Simpolis` už v iCloud Drive je a krok 1 přeskoč.

1. **Přesuň složku `Simpolis`** ve Finderu z Dokumentů do iCloud Drive.
2. **Klikni na ni pravým tlačítkem** a zvol **Vždy ponechat na tomto Macu**. Jinak by macOS soubory z disku uvolnil a Chrome by je nenašel.
3. **Otevři `chrome://extensions`, klikni na Načíst rozbalené** a vyber složku `Simpolis` v iCloud Drive. Šimpoliš je pořád stejný, nastavení i Trezor mu zůstanou.

Na dalším Macu počkej, až se složka v iCloud Drive objeví, udělej krok 2 a pak krok 4 až 8 z instalace se složkou v iCloud Drive.

## Co musí platit, aby hlídal

- **Chrome běží.**
- **Počítač nespí.** Když počítač uspíš, Šimpoliš usne taky.
- **Jsi v Chromu přihlášený do SIS** nebo máš povolený Trezor (viz níže).

Jak na tom Šimpoliš je, ověříš v okně šimpanze tlačítkem **Ověřit přihlášení**. U řádku bez zelené fajfky je odkaz, kde to spravíš: **Přihlásit do SIS**, **Povolit** Trezor, nebo **Nastavení**, kde Trezor založíš.

## Jak hlídat akci

1. **Klikni na šimpanze** vpravo nahoře v liště Chromu. Otevře se okno Šimpoliše.
2. **U akce zvol Hlídat.** Šimpoliš tím rovnou zapne i „Auto-přihlášení na akci“: hlídkuje, a jakmile se přihlášení otevře, zkusí tě na akci přihlásit automaticky.
3. **Zelené „Auto-přihlášení připravené“** znamená, že jsi přihlášený v SIS a máš povolený Trezor. Když poběží Chrome a počítač nebude spát, Šimpoliš tě pak zkusí přihlásit, i když u počítače zrovna nejsi.
4. **Nechceš, aby tě přihlásil automaticky?** U hlídané akce odškrtni „Auto-přihlášení na akci“. Šimpoliš tě pak jen upozorní, že se přihlašování otevřelo.

![Lišta Chromu: 1 je šimpanz vpravo od adresního řádku](navod/chrome-5-lista.svg)

![Okno Šimpoliše: 2 je tlačítko Hlídat u akce, 3 je zelené Auto-přihlášení připravené u hlídané akce](navod/okno-hlidat.png)

Akce, na kterou jsi přihlášený, se přesune do sekce **Přihlášeno**. Šimpoliš to pozná i tehdy, když se přihlásíš ručně nebo z jiného počítače: podívá se do tvého **Administrativního přehledu studenta** v SIS. Odhlásit se z ní můžeš jen v SIS, odkaz **Odhlásit se v SIS** tě pošle rovnou do tvého přehledu. Šimpoliš to pozná a vrátí akci mezi hlídané s vypnutým auto-přihlášením, takže tě znovu nepřihlásí.

Hlídání zrušíš tlačítkem **Nehlídat**, akce se vrátí do seznamu. Akci, kterou nechceš vůbec, schováš tlačítkem **Akci vynechám**. Když se spleteš, najdeš ji dole v sekci **Skryté akce** a vrátíš tlačítkem **Vrátit**.

**Přidat do kalendáře** najdeš u každé akce pod datem. Vybereš **Akce**, nebo **Připomínka přihlášení**. Připomínka je jen záznam v tvém kalendáři na chvíli, kdy se v SIS otevře přihlášení. **Přihlásit se pak musíš v SIS ručně.** Automaticky tě Šimpoliš zkusí přihlásit jen na akci, kterou hlídá s auto-přihlášením, a jen když poběží Chrome, počítač nebude spát a budeš mít povolený Trezor. Tlačítko **Připomínka do kalendáře** je i v notifikaci, která přijde, jakmile SIS čas otevření přihlášení ukáže.

Akce ze SIS, které nejsou ve veřejném harmonogramu, jsou ve sbalené sekci **Další akce v SIS**. Často jde o povinné semináře a praktické aplikace.

## Pravidla automatického přihlášení

- **Jen na akce, které sis vybral** a u kterých je zaškrtnuté „Auto-přihlášení na akci“.
- **U akcí mimo Skill-Port a Hosté VŠEM se nejdřív zeptá.** Až akci najde v SIS, ukáže přesný název a ty potvrdíš, že je to ona.
- **Jeden pokus na akci.** Když se něco pokazí, dá vědět a víc nezkouší. Tlačítko **Zkusit znovu** pokus povolí znovu.
- **Nikdy tě neodhlásí.**

## Barvy

Barva má význam jen u **stavu nahoře v okně šimpanze** a u **ikony šimpanze v liště**.

| Barva | Co znamená |
| --- | --- |
| 🔴 červený rámeček | Bez tebe Šimpoliš nefunguje. Třeba máš povolit Trezor nebo se přihlásit do SIS. |
| 🔵 modrý rámeček | Šimpoliš čeká na tvé rozhodnutí. Třeba se otevřelo přihlášení, nebo máš potvrdit akci. |
| 🟢 zelený text | Všechno je v pořádku. |

- **Ikona v liště:** v klidu je žlutá, při otevřeném přihlášení modrá s číslem, a když je potřeba tvůj krok, červená.
- **Modrá tlačítka** jako **Hlídat** nebo **Otevřít SIS** jen ukazují, kam kliknout.

## Trezor (nepovinný, ale doporučený)

SIS automaticky odhlašuje a Šimpoliš tě pak upozorní, že se máš přihlásit. Díky trezoru se Šimpoliš zvládne přihlásit do SISu automaticky, a tím i na hlídanou akci.

Pracuješ se dvěma hesly:

- **Heslo do SIS** uložíš do trezoru jednou a pak už ho nezadáváš.
- **Hlavní heslo trezoru** je jiné heslo, které si vymyslíš (aspoň 8 znaků). Nepoužívej ho nikde jinde.

Další pravidla:

- **Založení:** v Nastavení vyplň jméno a heslo do SIS a pak dvakrát nové hlavní heslo trezoru.
- **Po restartu Chromu** je Trezor vypnutý. Povolíš ho hlavním heslem.
- **Když automatické přihlášení z trezoru selže**, víckrát to nezkouší a toto přihlašování vypne. Přihlas se do SIS ručně, pak Trezor vypni a znovu povol.
- **Heslo do SIS je uložené zašifrované v prohlížeči** a odchází jen přes HTTPS na přihlašovací stránku školy.
- **Smazání:** v Nastavení v části Trezor klikni na **Smazat trezor** a potvrď **Ano, smazat**.
- **Hlavní heslo trezoru nejde obnovit.** Když ho zapomeneš, trezor smaž a založ znovu. Do SIS se tím nic nemění.
- **Změnil jsi heslo do SIS?** Trezor smaž a založ znovu.

## Co Šimpoliš sdílí

Šimpoliši různých uživatelů si předávají seznam akcí z webu školy a SISu.

- **Co odchází:** názvy, popisy a termíny akcí, kdy se na ně dá přihlásit a jakou mají kapacitu. Stejné údaje vidí v SIS každý student.
- **Co nikdy neodchází:** tvoje jméno, heslo, studijní číslo, trezor, akce, na které jsi přihlášený, ani akce, které hlídáš nebo které tě nezajímají.
- **Kam:** do skriptu Google Apps Script na účtu autora Šimpoliše. Ten seznam uloží na Google Disk autora a zveřejní ho jako [veřejný katalog akcí](https://tomekson.github.io/simpolis-data/katalog.json). Seznam od ostatních si Šimpoliš stahuje ze stejného skriptu.
- **Bez identifikace:** Šimpoliš k seznamu nepřikládá tvůj Google účet ani přihlášení do SIS. Google jako provozovatel skriptu vidí jen tvou IP adresu, stejně jako u každé webové stránky.
- **Synchronizace mezi tvými počítači:** hlídané a skryté akce a volbu ranní zprávy si Chrome ukládá do tvého účtu Google, když máš zapnutou synchronizaci. Autor Šimpoliše ani ostatní je nevidí. Heslo do SIS ani Trezor se nesynchronizují.
- **Kontrola nové verze:** jednou za 6 hodin si Šimpoliš stáhne z webu návodu malý soubor s číslem nejnovější verze. Nic přitom neodesílá.
- **Žádná statistika.** Šimpoliš nesleduje, jak ho používáš.

## Jak často se vše kontroluje

Jen tak často, jak je potřeba:

- **Když nehlídáš žádnou akci:** sleduje novinky na webu školy každou hodinu.
- **Akce je za více než 14 dní:** hlídá jednou za 10 minut.
- **Akce se blíží:** hlídá přihlášení každou minutu, v noci mezi 21 a 6 h jednou za 5 minut.
- **Když tě SIS odhlásí:** zkouší to každých 10 minut. Rychlejší je tlačítko **Přihlásit do SIS** v okně Šimpoliše: otevře SIS a jakmile se přihlásíš, Šimpoliš to do pár sekund ověří.
