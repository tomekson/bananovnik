import { createVault, unlockVault } from './vault.js';

const $ = (id) => document.getElementById(id);

function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c);
  return e;
}

const send = (msg) => chrome.runtime.sendMessage(msg);

function note(box, text, bad = true) {
  box.querySelector('.note')?.remove();
  box.append(el('p', { class: `note small`, style: bad ? 'color: var(--red)' : 'color: var(--green)' }, text));
}

let editing = false;

function renderVault(st, vaultKey) {
  const box = $('vault');
  if (editing) return;
  box.replaceChildren();
  const field = (placeholder, type = 'password', autocomplete = 'off') => el('input', { type, placeholder, autocomplete });

  if (!st.vault) {
    const u = field('jméno do SIS (e-mail)', 'text');
    const p = field('heslo do SIS');
    const m1 = field('nové hlavní heslo trezoru', 'password', 'new-password');
    const m2 = field('nové hlavní heslo trezoru znovu', 'password', 'new-password');
    const form = el('form', { class: 'stack', onfocusin: () => (editing = true) },
      el('h3', {}, '1. Přihlášení do SIS'),
      el('p', { class: 'small' }, 'Stejné jméno a heslo, jakými se přihlašuješ do SIS'),
      u, p,
      el('h3', {}, '2. Hlavní heslo trezoru'),
      el('p', { class: 'small' }, 'Nové heslo, jiné než do SIS, aspoň 8 znaků. Budeš ho zadávat po každém restartu Chromu.'),
      m1, m2,
      el('button', { type: 'submit', class: 'primary' }, 'Založit trezor'));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (m1.value !== m2.value) return note(box, 'Hlavní hesla trezoru se neshodují');
      if (m1.value === p.value) return note(box, 'Hlavní heslo trezoru musí být jiné než heslo do SIS');
      try {
        const { vault, keyB64 } = await createVault(m1.value, u.value.trim(), p.value);
        await chrome.storage.local.set({ vault });
        await chrome.storage.session.set({ vaultKey: keyB64 });
        editing = false;
        await send({ type: 'vaultUnlocked' });
      } catch (err) {
        note(box, err.message);
      }
    });
    return box.append(form);
  }

  box.append(el('p', { class: 'small' }, 'Povolit a vypnout Trezor můžeš v liště nahoře na stránce nebo v okně Šimpoliše'));
  const del = el('div', { class: 'actions' });
  const askDelete = () =>
    del.replaceChildren(
      el('span', {}, 'Opravdu smazat trezor? Uložené heslo do SIS zmizí.'),
      el('button', {
        type: 'button',
        class: 'danger',
        onclick: async () => {
          await chrome.storage.session.remove('vaultKey');
          await chrome.storage.local.remove('vault');
        },
      }, 'Ano, smazat'),
      el('button', { type: 'button', onclick: () => del.replaceChildren(deleteButton()) }, 'Ne')
    );
  const deleteButton = () => el('button', { type: 'button', class: 'quiet', onclick: askDelete }, 'Smazat trezor');
  del.append(deleteButton());
  box.append(del);
}

// Lišta nahoře: stav trezoru a zamknout/odemknout, ať se nemusí hledat uprostřed stránky.
function renderVaultBar(st, vaultKey) {
  const bar = $('vaultbar');
  if (bar.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // rozepsané heslo
  bar.hidden = false;
  bar.className = 'vaultbar';
  if (!st.vault) {
    return bar.replaceChildren(
      el('p', {}, '🔓 Trezor nemáš. Po odhlášení ze SIS tě Šimpoliš zpátky nepřihlásí.'),
      el('button', { type: 'button', onclick: () => $('vault-section').scrollIntoView({ behavior: 'smooth' }) }, 'Založit trezor')
    );
  }
  if (!vaultKey) {
    const m = el('input', { type: 'password', placeholder: 'heslo Trezoru', autocomplete: 'current-password' });
    const form = el('form', { class: 'inline' }, m, el('button', { type: 'submit', class: 'primary' }, 'Povolit Trezor'));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await chrome.storage.session.set({ vaultKey: await unlockVault(st.vault, m.value) });
        m.blur();
        await send({ type: 'vaultUnlocked' });
      } catch (err) {
        note(bar, err.message);
      }
    });
    return bar.replaceChildren(el('p', {}, '🔒 Trezor je vypnutý'), form);
  }
  if (st.vaultFailed) bar.classList.add('red');
  bar.replaceChildren(
    el('p', {}, st.vaultFailed ? '⚠️ Přihlášení z Trezoru selhalo. Přihlas se do SIS ručně, pak Trezor vypni a znovu povol.' : '🔓 Trezor je povolený, dokud nezavřeš Chrome'),
    el('button', { type: 'button', onclick: () => chrome.storage.session.remove('vaultKey') }, 'Vypnout Trezor')
  );
}

function render(st, vaultKey) {
  renderVaultBar(st, vaultKey);
  renderVault(st, vaultKey);
  const sh = st.share ?? {};
  const when = (t) => (t ? new Date(t).toLocaleString('cs-CZ') : 'zatím nikdy');
  $('share').textContent = `Sdílený seznam akcí: SIS ${st.sis?.source === 'shared' ? 'převzatý od jiného Šimpoliše' : 'z vlastní kontroly'}, naposledy odesláno ${when(sh.sentAt)}.${sh.error ? ` Poslední chyba: ${sh.error}` : ''}`;
  const v = chrome.runtime.getManifest().version;
  // Ticho, když synchronizace funguje; ozvat se jen při chybě nebo oříznutí.
  $('sync').textContent = st.syncError ? `Synchronizace mezi počítači: ${st.syncError}` : '';
  $('sync').hidden = !st.syncError;
  $('version').textContent = `Verze ${v}${st.updatedTo === v && st.updatedAt ? `, aktualizováno ${new Date(st.updatedAt).toLocaleString('cs-CZ')} z verze ${st.updatedFrom}` : ''}.`;
  $('heartbeat').checked = st.heartbeat !== false;
  const next = st.sis?.nextCheck;
  $('plan').textContent = next
    ? `Další kontrola v ${new Date(next).toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' })}${st.sis.nextReason ? ` (${st.sis.nextReason})` : ''}.`
    : '';
  const log = st.session?.log ?? [];
  $('sessions').replaceChildren(
    ...(log.length
      ? log.map((s) => el('li', {}, `${new Date(s.start).toLocaleString('cs-CZ')}: ${s.partial ? 'aspoň ' : ''}${s.minutes} min`))
      : [el('li', {}, 'Zatím tě SIS neodhlásil')])
  );
  const res = st.responses ?? [];
  $('responses').replaceChildren(
    ...(res.length
      ? res.map((r) =>
          el('li', {}, `${new Date(r.at).toLocaleString('cs-CZ')} · akce ${r.sisId} · HTTP ${r.status}${r.redirected ? ' (přesměrováno)' : ''} · ${r.path}${r.flash ? ` · ${r.flash}` : ''}${r.hasForm ? ' · formulář' : ''}`))
      : [el('li', {}, 'Zatím žádný pokus')])
  );
}

async function refresh() {
  const [st, { vaultKey }] = await Promise.all([chrome.storage.local.get(null), chrome.storage.session.get('vaultKey')]);
  render(st, vaultKey);
}

// Vzhled: uloží se do localStorage rozšíření, theme.js ho načte dřív, než se stránka vykreslí.
const savedTheme = (() => { try { return localStorage.getItem('theme'); } catch { return null; } })();
for (const r of document.querySelectorAll('input[name="theme"]')) {
  r.checked = r.value === (savedTheme === 'light' || savedTheme === 'dark' ? savedTheme : 'auto');
  r.addEventListener('change', () => {
    try {
      if (r.value === 'auto') localStorage.removeItem('theme');
      else localStorage.setItem('theme', r.value);
    } catch { /* bez localStorage platí vzhled systému */ }
    if (r.value === 'auto') delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = r.value;
  });
}

for (const name of ['heartbeat']) {
  $(name).addEventListener('change', (e) => send({ type: 'setOption', name, value: e.target.checked }));
}
chrome.storage.onChanged.addListener(() => refresh());
refresh();

// Verze vedle (beta) v hlavičce: hned vidět, co běží.
document.getElementById('beta').textContent = `(beta ${chrome.runtime.getManifest().version})`;
