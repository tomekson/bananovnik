// Šimpoliš - čistá logika bez chrome API: katalog akcí, párování se SIS,
// texty pro uživatele, stav popupu a plán kontrol. Používá ji service worker,
// popup i testy.
import { normalize, isAutoAllowed, toMs } from './parser.js';

export const DAY_MS = 24 * 3600_000;
const WEEKDAYS = ['ne', 'po', 'út', 'st', 'čt', 'pá', 'so'];

// ---------- texty ----------

export function slotKey(date, time) {
  return `${date}|${time ?? ''}`;
}

const shortTime = (t) => t.replace(/^0(\d)/, '$1');

// "po 14. 12. v 17:00"; rok jen když není letošní.
export function formatWhen(date, time, now = Date.now(), { withV = true } = {}) {
  if (!date) return 'termín neznámý';
  const [y, m, d] = date.split('-').map(Number);
  const wd = WEEKDAYS[new Date(y, m - 1, d).getDay()];
  const year = y !== new Date(now).getFullYear() ? ` ${y}` : '';
  const t = time ? `${withV ? ' v' : ''} ${shortTime(time)}` : '';
  return `${wd} ${d}. ${m}.${year}${t}`;
}

export const formatDt = (dt, now) => (dt?.date ? formatWhen(dt.date, dt.time, now) : '?');

// "Skill-Port VŠEM" + "Umění emoční regulace" -> "Skill-Port: Umění emoční regulace";
// "Advertising Night VŠEM" + "Advertising Night VŠEM: Christmas Edition" -> jen název.
export function cleanTitle(type, title) {
  const short = String(type ?? '').replace(/\s*VŠEM\s*$/i, '').trim();
  if (!title) return type;
  if (!short || normalize(title).startsWith(normalize(short))) return title;
  return `${short}: ${title}`;
}

export const isOnline = (s) => /teams|on-?line|zoom|webin/i.test(String(s ?? ''));
const inBuilding = (s) => /budov|prezen/i.test(String(s ?? ''));

// ---------- katalog akcí ----------

const startMs = (date, time) => (date ? toMs({ date, time: time ?? '23:59' }) : null);

// Sloučí veřejný harmonogram a SIS do karet. Stejné datum a čas začátku = stejná akce.
export function buildCatalog(harmoRows = [], sisRows = [], now = Date.now()) {
  const bySlot = new Map();
  for (const r of sisRows) {
    if (!r.start?.date) continue;
    const k = slotKey(r.start.date, r.start.time);
    if (!bySlot.has(k)) bySlot.set(k, []);
    bySlot.get(k).push(r);
  }
  const absorbed = new Set();
  const web = [];
  const usedKeys = new Set();
  for (const h of harmoRows) {
    if (!h.viaSis || !h.date) continue;
    const slot = slotKey(h.date, h.time);
    let key = `w|${slot}`;
    if (usedKeys.has(key)) key = `w|${slot}|${normalize(h.type)}|${normalize(h.title)}`; // dvě akce ve stejný čas
    usedKeys.add(key);
    const cands = bySlot.get(slot) ?? [];
    const prefix = normalize(h.type);
    const named = cands.filter((r) => normalize(r.name).startsWith(prefix));
    const mine = named.length ? named : cands.length === 1 ? cands : [];
    mine.forEach((r) => absorbed.add(r));
    const sis = mine.length === 1 ? mine[0] : null;
    web.push(card({
      key,
      source: 'web',
      slot,
      title: cleanTitle(h.type, h.title),
      type: h.type,
      date: h.date,
      time: h.time,
      online: h.online,
      inBuilding: !h.online,
      place: h.place,
      sis,
      sisCount: mine.length,
    }));
  }
  const webSlots = new Set(web.map((c) => c.slot));
  const sisOnly = [];
  for (const r of sisRows) {
    if (absorbed.has(r) || !r.start?.date) continue;
    const slot = slotKey(r.start.date, r.start.time);
    if (webSlots.has(slot) && (bySlot.get(slot) ?? []).length === 1) continue;
    const text = `${r.name} ${r.descrip}`;
    sisOnly.push(card({
      key: `s|${slot}|${normalize(r.name)}`,
      source: 'sis',
      slot,
      title: r.name,
      type: null,
      date: r.start.date,
      time: r.start.time,
      online: isOnline(text),
      inBuilding: !isOnline(text) && inBuilding(text),
      place: null,
      sis: r,
      sisCount: 1,
    }));
  }
  const upcoming = (c) => c.startMs > now && !(c.sis?.signinTo && toMs(c.sis.signinTo) < now);
  return {
    web: web.filter(upcoming).sort((a, b) => a.startMs - b.startMs),
    sisOnly: sisOnly.filter(upcoming).sort((a, b) => a.startMs - b.startMs),
  };
}

function card(c) {
  c.startMs = startMs(c.date, c.time);
  c.signinOpen = Boolean(c.sis?.canSignIn);
  c.signinFrom = c.sis?.signinFrom ?? null;
  c.capacity = c.sis?.capacity ?? null;
  return c;
}

// Stav přihlášení na kartě nehlídané akce.
export function signinText(c, now = Date.now()) {
  if (c.signinOpen) return c.capacity !== null ? `V SIS se teď můžeš přihlásit (volno ${c.capacity})` : 'V SIS se teď můžeš přihlásit';
  if (c.sis && c.capacity !== null && c.capacity <= 0 && (!c.signinFrom || toMs(c.signinFrom) <= now)) return 'Plno.';
  if (c.signinFrom && toMs(c.signinFrom) > now) return `Přihlášení od ${formatDt(c.signinFrom, now)}`;
  if (c.sisCount > 1) return 'V SIS je na stejný čas víc akcí';
  if (!c.sis) return 'Zatím jen ohlášená, v SIS ještě není';
  return 'V SIS už je, přihlášení zatím není';
}

// Výchozí auto-přihlášení při volbě Hlídat: vždy zapnuté (rozhodnutí 20. 11. 2026), uživatel ho může vypnout.
// Akce mimo Skill-Port/Hosté z harmonogramu se dál nejdřív potvrzují proti řádku SIS (needsConfirm).
export const defaultAuto = () => true;

// ---------- hlídání ----------

export function newWatchFromCard(c, auto) {
  const viaType = c.source === 'web' && isAutoAllowed(c.type);
  return {
    key: c.key,
    source: c.source,
    label: c.title,
    date: c.date,
    time: c.time,
    online: c.online,
    inBuilding: c.inBuilding,
    place: c.place,
    // Web Skill-Port/Hosté: pozná se podle typu. SIS: uživatel viděl přesný název.
    namePrefix: viaType ? c.type : c.source === 'sis' ? c.title : null,
    confirmedName: c.source === 'sis' ? c.title : null,
    confirmedId: c.source === 'sis' ? (c.sis?.id ?? null) : null,
    rejectedNames: [],
    auto: Boolean(auto),
    state: 'waiting',
    msg: '',
    attempted: false,
    sisId: null,
    sisName: null,
    signinFrom: null,
    signinTo: null,
    capacity: null,
    updatedAt: Date.now(),
  };
}

// Řádky SIS, které odpovídají hlídané akci.
export function matchRows(w, rows) {
  const prefix = normalize(w.namePrefix);
  const rejected = new Set((w.rejectedNames ?? []).map(normalize));
  return rows.filter(
    (r) =>
      r.start?.date === w.date &&
      (!w.time || r.start?.time === w.time) &&
      (!prefix || normalize(r.name).startsWith(prefix)) &&
      (!w.confirmedName || normalize(r.name) === normalize(w.confirmedName)) &&
      !rejected.has(normalize(r.name))
  );
}

export function nearRows(w, rows) {
  if (!w.namePrefix) return [];
  const prefix = normalize(w.namePrefix);
  return rows.filter((r) => r.start?.date === w.date && normalize(r.name).startsWith(prefix));
}

// Řádek, který uživatel potvrdil (nebo vybral přímo ze SIS): stejný název
// a, když obě strany ID znají, i stejné ID.
export function isConfirmedRow(w, row) {
  if (!w.confirmedName || normalize(w.confirmedName) !== normalize(row.name)) return false;
  return !(w.confirmedId && row.id && w.confirmedId !== row.id);
}

// Hlídání Skill-Portu/Hostů z webu: řádek se pozná podle názvu, potvrzení netřeba.
const byTypeSafe = (w, row) => Boolean(w.namePrefix) && isAutoAllowed(w.namePrefix) && isAutoAllowed(row.name);

// Smí se Šimpoliš na tenhle řádek přihlásit sám?
export function mayAutoSign(w, row) {
  if (!w.auto) return false;
  return byTypeSafe(w, row) || isConfirmedRow(w, row);
}

// Před auto-přihlášením musí uživatel potvrdit konkrétní řádek SIS.
export const needsConfirm = (w, row) => w.auto && !mayAutoSign(w, row);

const FINAL = ['registered', 'probably', 'closed', 'failed', 'needs-confirm'];
export const isActive = (w) => !FINAL.includes(w.state);

// Jedna věta na kartě hlídané akce. Co se stane při otevření, říká zaškrtávátko pod ní.
export function watchSentence(w, now = Date.now()) {
  switch (w.state) {
    case 'waiting':
      return {
        kind: 'wait',
        text: w.source === 'sis' ? 'V SIS teď není' : 'Zatím jen ohlášená, v SIS ještě není',
      };
    case 'listed':
      return {
        kind: 'wait',
        text:
          w.signinFrom && toMs(w.signinFrom) > now
            ? `Přihlášení se otevře ${formatDt(w.signinFrom, now)}`
            : 'V SIS už je, přihlášení zatím není',
      };
    case 'signing':
      return { kind: 'wait', text: 'Šimpoliš tě právě přihlašuje…' };
    case 'open':
      return { kind: 'open', text: 'V SIS se teď můžeš přihlásit' };
    case 'registered':
      return { kind: 'done', text: '✅ Přihlášeno' };
    case 'probably':
      return { kind: 'done', text: '✅ Nejspíš přihlášeno, ověř to v SIS' };
    case 'confirm':
      return { kind: 'need', text: `Potvrď: je „${w.confirmFor?.name ?? w.sisName}“ ta akce, kterou chceš?` };
    default:
      return { kind: 'need', text: w.msg };
  }
}

// ---------- stav nahoře v popupu ----------

// Seřazené položky: red (blokuje) > blue (příležitost, rozhodnutí) > green.
const akce = (n) => `${n} ${n === 1 ? 'akci' : n < 5 ? 'akce' : 'akcí'}`;

// Zelený stav popisuje, co funguje. Uživateli nic neukládá, když nic dělat nemusí.
// „Vše v pořádku“ jen s přihlášeným Trezorem. Bez něj SIS drží jen do příštího odhlášení: „zatím“.
function okText(st, active, vaultLocked) {
  const watching = `Šimpoliš hlídá ${akce(active.length)}`;
  const sisOk = st.session?.status === 'ok';
  if (st.vault && !vaultLocked && !st.vaultFailed) {
    return `Vše v pořádku: ${watching}${sisOk ? ', SIS přihlášený' : ''}, Trezor povolený`;
  }
  return sisOk ? `${watching}, SIS zatím přihlášený` : watching;
}

// Výsledek tlačítka Ověřit přihlášení: tři řádky, ❌ u toho, co brání přihlášení.
// Automatické přihlašování funguje jen tehdy, když je SIS přihlášený, nebo ho umí obnovit trezor.
export function checkSummary(st, { vaultLocked = false } = {}) {
  const sisOk = st.session?.status === 'ok' && !st.sis?.error && !st.sis?.detour;
  const canRelogin = Boolean(st.vault) && !vaultLocked && !st.vaultFailed;
  const sis = st.sis?.error ? '❌ SIS neodpovídá' : st.sis?.detour ? '❌ SIS po tobě něco chce' : sisOk ? '✅ SIS přihlášený' : '❌ SIS odhlášený';
  const vault = !st.vault
    ? '🔑 Trezor nemáš'
    : st.vaultFailed
      ? '❌ Trezor selhal, přihlas se do SIS ručně'
      : vaultLocked
        ? `${sisOk ? '🔒' : '❌'} Trezor vypnutý`
        : '✅ Trezor povolený';
  const auto = st.autoPaused
    ? '❌ automatické přihlašování vypnuté'
    : sisOk || canRelogin
      ? '✅ automatické přihlašování aktivní'
      : '❌ automatické přihlašování neaktivní';
  // Spárování je nepovinné: řádek jen u spárovaného počítače.
  const pair = !st.pair?.code ? [] : st.pair.error ? ['❌ spárování nefunguje'] : ['✅ Spárováno s jiným PC'];
  return [sis, auto, vault, ...pair];
}

// Auto-přihlášení na hlídanou akci je opravdu připravené: zapnuté, Šimpoliš není zastavený,
// SIS je přihlášený a odemčený Trezor ho po odhlášení přihlásí zpátky.
export function autoReady(st, w, { vaultLocked = false } = {}) {
  return Boolean(w.auto) && isActive(w) && !['confirm', 'needs-confirm', 'ambiguous', 'mismatch'].includes(w.state)
    && !st.autoPaused && !st.sis?.detour && st.release?.state !== 'blocked'
    && st.session?.status === 'ok' && Boolean(st.vault) && !vaultLocked && !st.vaultFailed;
}

export function statusItems(st, { vaultLocked = false } = {}) {
  const rel = st.release ?? {};
  if (rel.state === 'blocked') {
    const why = rel.reason === 'ended'
      ? 'Šimpoliš skončil a už nic nehlídá'
      : `Tahle verze Šimpoliše už nefunguje a nic nehlídá. Stáhni verzi ${rel.latest}.`;
    return [{ level: 'red', kind: 'release', url: rel.url, text: rel.message ? `${why} ${rel.message}` : why }];
  }
  const items = [];
  if (rel.state === 'update') {
    items.push({ level: 'blue', kind: 'release', url: rel.url, text: `Je nová verze ${rel.latest}. Stáhni ji a nahraď jí složku „Simpolis“.${rel.message ? ` ${rel.message}` : ''}` });
  }
  const watches = st.watches ?? [];
  const expired = st.session?.status === 'expired';
  if (expired && st.vault && vaultLocked && !st.vaultFailed) {
    items.push({ level: 'red', kind: 'unlock', text: 'Povol Trezor, ať tě Šimpoliš může přihlašovat na akce' });
  } else if (expired && st.vault && !st.vaultFailed) {
    // Trezor je odemčený: Šimpoliš se do SIS přihlásí sám, uživatel nemusí nic.
    items.push({ level: 'green', kind: 'progress', text: 'Šimpoliš se přihlašuje do SIS…' });
  } else if (expired) {
    items.push({ level: 'red', kind: 'login', text: 'Přihlas se do SIS' });
  }
  if (st.sis?.detour && !expired) {
    items.push({ level: 'red', kind: 'detour', text: 'SIS po tobě něco chce' });
  }
  if (st.autoPaused) {
    items.push({ level: 'red', kind: 'resume', text: `Automatické přihlašování je vypnuté: ${st.pauseReason}` });
  }
  for (const w of watches) {
    if (w.state === 'open') items.push({ level: 'blue', kind: 'open', key: w.key, text: `Na „${w.label}“ se teď můžeš přihlásit v SIS` });
    if (w.state === 'confirm') items.push({ level: 'blue', kind: 'confirm', key: w.key, text: `Potvrď akci: je „${w.confirmFor?.name ?? w.sisName}“ ta, kterou chceš?` });
    if (['failed', 'needs-confirm', 'ambiguous', 'mismatch'].includes(w.state)) {
      items.push({ level: 'blue', kind: 'need', key: w.key, text: `${w.label}: ${w.msg}` });
    }
  }
  for (const w of watches) {
    if (['registered', 'probably'].includes(w.state) && Date.now() - (w.updatedAt ?? 0) < DAY_MS) {
      items.push({ level: 'green', kind: 'done', key: w.key, text: `✅ Přihlášeno na „${w.label}“` });
    }
  }
  if (!items.some((i) => i.level !== 'green' || i.kind === 'progress')) {
    const active = watches.filter(isActive);
    items.push(
      active.length
        ? { level: 'green', kind: 'ok', text: okText(st, active, vaultLocked) }
        : { level: 'green', kind: 'idle', text: watches.length ? 'Hotovo. Další akci vyber níže.' : 'Šimpoliš nic nehlídá. V Nastavení založ Trezor a přihlášení do SIS, pak vyber školní akci ze seznamu.' }
    );
  }
  const rank = { red: 0, blue: 1, green: 2 };
  return items.sort((a, b) => rank[a.level] - rank[b.level]);
}

// Ikona v liště podle nejvážnější položky.
export function iconLevel(st, opts) {
  const top = statusItems(st, opts)[0];
  return top.level === 'red' ? 'block' : top.level === 'blue' ? 'open' : 'idle';
}

// ---------- plán kontrol ----------

export const RHYTHM = {
  minGap: 30_000, // Chrome alarm a zároveň nejvýš 1 dotaz na SIS za 30 s
  dayMin: 50_000,
  dayMax: 90_000,
  night: 5 * 60_000, // 21:00-6:00
  far: 10 * 60_000, // akce za víc než 14 dní
  farDays: 14,
  idle: 60 * 60_000, // nic nehlídám: jen kvůli notifikacím o nových akcích
  loggedOut: 10 * 60_000,
  waitingUser: 5 * 60_000, // otevřeno nebo potvrzení: čeká se na uživatele
  burst: 30_000, // prvních 5 minut po známém čase otevření
  burstWindow: 5 * 60_000,
  wakeAfterOpen: 3_000, // přesné probuzení pár sekund po otevření
  errors: [null, 2 * 60_000, 5 * 60_000],
};

// Noční režim platí vždycky (21:00-6:00): známý čas otevření stejně zachytí přesné probuzení.
const isNight = (t) => new Date(t).getHours() >= 21 || new Date(t).getHours() < 6;

// Kdy příště zkontrolovat SIS. random() jde podstrčit v testech.
export function planNext(st, now = Date.now(), random = Math.random) {
  const R = RHYTHM;
  const streak = st.sis?.errStreak ?? 0;
  if (streak > 0) {
    const backoff = R.errors[Math.min(streak, R.errors.length) - 1];
    if (backoff) return { when: now + backoff, reason: 'SIS neodpovídá, další pokus později' };
  }
  if (st.session?.status === 'expired') return { when: now + R.loggedOut, reason: 'čeká na přihlášení do SIS' };

  const cands = [{ when: now + R.idle, reason: 'kontrola nových akcí' }];
  for (const w of st.watches ?? []) {
    if (!isActive(w)) continue;
    const from = toMs(w.signinFrom);
    if (w.state === 'listed' && from && from > now) {
      cands.push({ when: from + R.wakeAfterOpen, reason: `přesně při otevření přihlášení (${formatDt(w.signinFrom, now)})` });
      continue;
    }
    if (from && now >= from && now - from < R.burstWindow && ['listed', 'waiting'].includes(w.state)) {
      cands.push({ when: now + R.burst, reason: 'přihlášení se právě otevírá' });
      continue;
    }
    if (['open', 'confirm', 'full', 'ambiguous', 'mismatch'].includes(w.state)) {
      cands.push({ when: now + R.waitingUser, reason: 'čeká na tvoje rozhodnutí' });
      continue;
    }
    const days = ((startMs(w.date, w.time) ?? now) - now) / DAY_MS;
    if (days > R.farDays) cands.push({ when: now + R.far, reason: 'akce je víc než 14 dní daleko' });
    else if (isNight(now)) cands.push({ when: now + R.night, reason: 'noční režim' });
    else cands.push({ when: now + R.dayMin + Math.floor(random() * (R.dayMax - R.dayMin)), reason: 'běžné hlídání' });
  }
  const best = cands.reduce((a, b) => (b.when < a.when ? b : a));
  return { ...best, when: Math.max(best.when, now + R.minGap) };
}
