import { SIS_LIST_URL, HARMONOGRAM_URL } from './parser.js';
import { buildCatalog, statusItems, checkSummary, autoReady, iconLevel, isActive, watchSentence, signinText, formatWhen, formatDt } from './model.js';
import { unlockVault } from './vault.js';
import { calendarEvent, signinEvent, googleUrl, outlookUrl, icsFile } from './calendar.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
if (params.get('page')) document.body.classList.add('page');
let focusKey = params.get('focus');
let showUnlock = false;

// Zaškrtávátko automatického přihlášení + (i) s vysvětlením ve sdíleném popoveru (popup.html).
// ready: SIS přihlášený a odemčený Trezor, Šimpoliš tě přihlásí bez tebe → zeleně „připravené“.
function autoCheck(checked, onchange, ready = false) {
  const input = el('input', { type: 'checkbox', checked, onchange: (e) => onchange(e.target.checked) });
  const info = el('button', { type: 'button', class: 'info', popovertarget: 'auto-info', 'aria-label': 'Co dělá auto-přihlášení' }, 'i');
  const text = ready ? 'Auto-přihlášení připravené' : 'Auto-přihlášení na akci';
  return { input, label: el('span', { class: `check${ready ? ' ready' : ''}` }, el('label', { class: 'check' }, input, text), info) };
}

function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c);
  return e;
}

async function send(msg) {
  const res = await chrome.runtime.sendMessage(msg);
  if (res && !res.ok && res.error) toast(res.error);
  return res;
}

function toast(text) {
  const t = el('div', { class: 'toast' }, text);
  document.body.append(t);
  setTimeout(() => t.remove(), 4000);
}

const openSis = () => chrome.tabs.create({ url: SIS_LIST_URL });
// Přihlásit do SIS: otevřít SIS a nechat service worker minutu sledovat ten panel.
// Jakmile se z přihlašovací stránky vrátí do SIS, Šimpoliš hned ověří přihlášení.
async function openSisLogin() {
  const tab = await chrome.tabs.create({ url: SIS_LIST_URL });
  await send({ type: 'watchLogin', tabId: tab.id });
}
const openVaultSettings = () => chrome.tabs.create({ url: chrome.runtime.getURL('options.html#vault-section') });
const openPairSettings = () => chrome.tabs.create({ url: chrome.runtime.getURL('options.html#pair-section') });
document.getElementById('harmo-link').href = HARMONOGRAM_URL;
document.getElementById('sis-link').href = SIS_LIST_URL;
// Potvrzení nese řádek, který uživatel právě vidí; když se v SIS mezitím změnil, service worker ho odmítne.
const confirmMatchW = (w, yes) => send({ type: 'confirmMatch', key: w.key, yes, name: w.confirmFor?.name, id: w.confirmFor?.id ?? null });
const confirmMatch = (st, key, yes) => {
  const w = (st.watches ?? []).find((x) => x.key === key);
  return w ? confirmMatchW(w, yes) : null;
};
const button = (label, onclick, cls = '') => el('button', { type: 'button', class: cls, onclick }, label);
// Tlačítko u karty: hned po kliknutí ukáže, co se děje (text + zešedlá karta), dokud změna neproběhne.
// Kartu pak překreslí nový stav; když se to nepovede, tlačítko se vrátí a ukáže chybu.
const act = (label, busy, msg, cls = '') =>
  el('button', { type: 'button', class: cls, onclick: async (e) => {
    const b = e.currentTarget;
    const card = b.closest('.card');
    b.disabled = true;
    b.textContent = busy;
    card?.classList.add('pending');
    const r = await send(msg);
    if (r && r.ok === false) {
      b.disabled = false;
      b.textContent = label;
      card?.classList.remove('pending');
      toast(r.error ?? 'Nepovedlo se, zkus to znovu');
    }
  } }, label);

function placeOf(c) {
  if (c.online) return c.place && c.source === 'web' ? c.place : 'online';
  return c.inBuilding ? 'osobně' : '';
}

// Časový sloupec karty jako v hlídkovém záznamu: den, hodina, rok jen když není letošní.
const DAYS = ['ne', 'po', 'út', 'st', 'čt', 'pá', 'so'];
function stamp(c) {
  if (c.key) calTargets.set(c.key, c);
  if (!c.date) return el('div', { class: 'stamp' }, el('span', { class: 'day' }, 'termín'), el('span', { class: 'day' }, 'neznámý'));
  const d = new Date(`${c.date}T12:00:00`);
  const year = d.getFullYear() !== new Date().getFullYear() ? String(d.getFullYear()) : null;
  return el('div', { class: 'stamp' },
    el('span', { class: 'day' }, `${DAYS[d.getDay()]} ${d.getDate()}. ${d.getMonth() + 1}.`),
    c.time ? el('span', { class: 'time' }, c.time) : null,
    year ? el('span', { class: 'day' }, year) : null,
    el('button', { type: 'button', class: 'cal-link', onclick: () => openCalendar(c) }, 'Přidat do kalendáře'));
}

// Nabídka kalendářů ve sdíleném popoveru (popup.html). Když je čas otevření přihlášení
// ještě před námi, jde přidat i připomínku „Přihlas se v SIS: …“. Je to jen záznam v kalendáři:
// text musí říct, že přihlášení zařídí uživatel sám (nebo Šimpoliš, ale jen u hlídané akce s auto).
const calTargets = new Map(); // klíč karty -> karta, kvůli otevření z notifikace (?cal=signin)
let watchByKey = new Map(); // klíč -> hlídání, kvůli textu připomínky
let myEventsUrl = SIS_LIST_URL; // Administrativní přehled studenta (přihlášené akce), když ho Šimpoliš zná
function openCalendar(c, pick = 'event') {
  const events = { event: calendarEvent(c), signin: signinEvent(c) };
  if (!events.event && !events.signin) return;
  const show = (which) => {
    const ev = events[which];
    const ics = () => {
      const url = URL.createObjectURL(new Blob([icsFile(ev)], { type: 'text/calendar' }));
      const name = ev.title.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').toLowerCase();
      el('a', { href: url, download: `${name || 'akce'}.ics` }).click();
      setTimeout(() => URL.revokeObjectURL(url), 10_000);
    };
    const choice = (key, label) =>
      el('button', { type: 'button', class: 'cal-choice', 'aria-pressed': String(which === key), onclick: () => show(key) }, label);
    $('cal-choice').replaceChildren(...(events.signin && events.event ? [choice('event', 'Akce'), choice('signin', 'Připomínka přihlášení')] : []));
    if (which === 'signin') {
      const w = watchByKey.get(c.key);
      const who = w && isActive(w) && w.auto
        ? 'Když poběží Chrome, počítač nebude spát a budeš mít povolený Trezor, Šimpoliš tě v tu chvíli zkusí přihlásit na akci automaticky. Připomínka je pojistka, kdyby se to nepovedlo.'
        : 'Šimpoliš tě nepřihlásí, přihlas se v SIS ručně. Chceš, aby to zkusil automaticky? U akce zvol Hlídat.';
      $('cal-what').replaceChildren(
        `Jen připomínka v tvém kalendáři: ${formatDt(c.signinFrom ?? c.sis?.signinFrom)} se v SIS otevře přihlášení na ${c.title ?? c.label}.`,
        el('strong', { class: 'cal-who' }, who));
    } else {
      $('cal-what').textContent = `${ev.title}, ${formatWhen(c.date, c.time)}`;
    }
    $('cal-links').replaceChildren(
      el('a', { class: 'cal-option', href: googleUrl(ev), target: '_blank', rel: 'noopener' }, 'Google Kalendář'),
      el('a', { class: 'cal-option', href: outlookUrl(ev), target: '_blank', rel: 'noopener' }, 'Outlook'),
      el('button', { type: 'button', class: 'cal-option', onclick: ics }, 'Soubor .ics (Apple Kalendář a ostatní)'));
  };
  show(events[pick] ? pick : events.event ? 'event' : 'signin');
  $('cal-menu').showPopover();
}

// Pod názvem jedna řádka: kde (online / osobně) a v jakém stavu akce je. Stav říká text, ne barevný pruh.
function cardBody(c, title, kind, text, ...rest) {
  const place = placeOf(c);
  return [stamp(c), el('div', { class: 'body' },
    el('p', { class: 'title' }, title),
    el('p', { class: `sentence ${kind}` },
      place ? el('span', { class: `place${c.online ? ' online' : ''}` }, place === 'online' || !c.online ? place : `online · ${place}`) : null,
      place ? ' · ' : null,
      text),
    ...rest)];
}

// ---------- stav nahoře ----------

// Klik na Povolit Trezor: ukázat pole a rovnou do něj dát kurzor, ať se dá hned psát heslo.
async function openUnlock() {
  showUnlock = true;
  await refresh();
  document.querySelector('form.inline input[type="password"]')?.focus();
}

function unlockForm(st) {
  const input = el('input', { type: 'password', placeholder: 'heslo Trezoru', autocomplete: 'current-password' });
  const form = el('form', { class: 'inline' }, input, el('button', { type: 'submit', class: 'primary' }, 'Povolit Trezor'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const keyB64 = await unlockVault(st.vault, input.value);
      // Pole pustit hned: dokud je v něm kurzor, stav nahoře se nepřekresluje (ochrana rozepsaného hesla).
      input.value = '';
      input.blur();
      showUnlock = false;
      await chrome.storage.session.set({ vaultKey: keyB64 });
      await refresh(); // hned „Šimpoliš se přihlašuje do SIS…“
      await send({ type: 'vaultUnlocked' });
      await refresh();
    } catch (err) {
      toast(err.message);
    }
  });
  return form;
}

function actionsFor(item, st) {
  switch (item.kind) {
    case 'unlock':
      return [unlockForm(st)];
    case 'login':
      return [button('Přihlásit do SIS', openSisLogin, 'primary')];
    case 'detour':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'resume':
      return [button('Zapnout znovu', () => send({ type: 'resume' }), 'primary')];
    case 'open':
      return [button('Otevřít SIS', openSis, 'primary')];
    case 'confirm':
      return [
        button('Ano, to je ona', () => confirmMatch(st, item.key, true), 'primary'),
        button('Ne, není', () => confirmMatch(st, item.key, false)),
      ];
    case 'release':
      return item.url ? [button('Otevřít návod', () => chrome.tabs.create({ url: item.url }), item.level === 'red' ? 'primary' : '')] : [];
    case 'need':
      return [button('Zkusit znovu', () => send({ type: 'retry', key: item.key })), button('Otevřít SIS', openSis)];
    default:
      return [];
  }
}

// Pravidlo ticha: když je vše v pořádku, jeden tichý řádek. Výrazný blok jen tehdy,
// když něco blokuje nebo čeká na rozhodnutí. Modré věci k akcím ukazují karty níže.
function renderStatus(st, vaultLocked) {
  const box = $('status');
  if (box.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // rozepsané heslo
  const items = statusItems(st, { vaultLocked });
  const [top] = items;
  if (top.level === 'green') {
    const ok = items.find((i) => ['progress', 'ok', 'idle'].includes(i.kind)) ?? top;
    box.replaceChildren(el('p', { class: `ok-line ${ok.kind}` }, ok.text));
    // Nic nehlídá a počítač není spárovaný: typicky čerstvá instalace na druhém počítači.
    if (ok.kind === 'idle' && !(st.watches ?? []).length && !st.pair?.code && $('check-result').hidden) { // jinak to říká řádek ⚪ ve výsledku kontroly
      box.append(el('p', { class: 'pair-hint' }, 'Máš Šimpoliše i na jiném počítači? ',
        el('button', { type: 'button', class: 'fix-link', onclick: openPairSettings }, 'Spáruj je v Nastavení')));
    }
  } else {
    const rest = items.slice(1).filter((i) => i.level === 'red' || i.kind === 'release');
    const progress = items.find((i) => i.kind === 'progress');
    box.replaceChildren(
      el('div', { class: `headline ${top.level} ${top.kind}` }, el('p', {}, top.text), el('div', { class: 'actions' }, actionsFor(top, st))),
      ...rest.map((i) => el('div', { class: `secondary ${i.level}` }, el('p', {}, i.text), el('div', { class: 'actions' }, actionsFor(i, st)))),
      ...(progress ? [el('p', { class: 'ok-line progress below' }, progress.text)] : [])
    );
  }
  // Zamčený trezor vadí jen tehdy, když má Šimpoliš někoho přihlásit sám.
  const autoWaiting = (st.watches ?? []).some((w) => isActive(w) && w.auto);
  // Klik na Povolit (třeba u výsledku Ověřit přihlášení) ukáže pole vždycky, i když nic nehlídáš.
  if (vaultLocked && (autoWaiting || showUnlock) && top.kind !== 'unlock') {
    box.append(
      el('div', { class: 'secondary grey' },
        el('p', {}, '🔒 Trezor je vypnutý. Když tě SIS odhlásí, Šimpoliš tě na akci nepřihlásí.'),
        showUnlock ? unlockForm(st) : el('div', { class: 'actions' }, button('Povolit Trezor', openUnlock)))
    );
  }
}

// Kdy Šimpoliš kontroloval, ukáže jen tehdy, když to něco znamená: SIS opakovaně
// neodpovídá, nebo poslední kontrola je podezřele stará.
function renderPulse(st) {
  const sis = st.sis ?? {};
  const p = $('pulse');
  let text = '';
  if ((sis.errStreak ?? 0) >= 2 && sis.error) text = sis.error;
  else if (sis.lastCheck && Date.now() - sis.lastCheck > 75 * 60_000) {
    text = `Naposledy zkontrolováno před ${Math.round((Date.now() - sis.lastCheck) / 3_600_000)} h`;
  }
  p.textContent = text;
  p.hidden = !text;
}

// ---------- karty ----------

function watchCard(w, c, ready = false) {
  const info = c ?? w;
  const s = watchSentence(w);
  const auto = autoCheck(w.auto, (on) => send({ type: 'setAuto', key: w.key, auto: on }), ready).label;
  const extra =
    w.state === 'open'
      ? [button('Otevřít SIS', openSis, 'primary')]
      : w.state === 'confirm'
        ? [button('Ano, to je ona', () => confirmMatchW(w, true), 'primary'), button('Ne, není', () => confirmMatchW(w, false))]
        : s.kind === 'need'
          ? [button('Zkusit znovu', () => send({ type: 'retry', key: w.key }))]
          : [];
  return el('li', { class: `card watched ${s.kind}`, 'data-key': w.key }, ...cardBody(info, w.label, s.kind, s.text,
    extra.length ? el('div', { class: 'actions' }, extra) : null,
    el('div', { class: 'actions split' }, ['registered', 'probably'].includes(w.state) ? el('span') : auto,
      el('div', { class: 'actions' },
        act('Nehlídat', 'Ruším hlídání…', { type: 'stopWatch', key: w.key }, 'quiet'),
        act('Akci vynechám', 'Schovávám…', { type: 'unwatch', key: w.key }, 'quiet')))));
}

// Katalog: jen Hlídat a Akci vynechám. Auto-přihlášení se ukáže až u hlídané akce,
// kde opravdu platí (předvolba podle typu akce, online z harmonogramu zapnuté).
// Přihlášená akce: hlídat už není co. Odhlásit se jde jen v SIS (Šimpoliš nikoho neodhlašuje).
function registeredCard(w, c) {
  const info = c ?? w;
  const s = watchSentence(w);
  return el('li', { class: 'card done', 'data-key': w.key }, ...cardBody(info, w.label, 'done', s.text,
    el('div', { class: 'actions split' }, el('span'),
      el('a', { class: 'quiet-link', href: myEventsUrl, target: '_blank' }, w.state === 'probably' ? 'Ověřit v SIS ↗' : 'Odhlásit se v SIS ↗'))));
}

function eventCard(c) {
  return el('li', { class: 'card', 'data-key': c.key }, ...cardBody(c, c.title, c.signinOpen ? 'open' : 'wait', signinText(c),
    el('div', { class: 'actions split' }, el('span'),
      el('div', { class: 'actions' },
        act('Hlídat', 'Přidávám…', { type: 'watchCard', key: c.key }, 'primary'),
        act('Akci vynechám', 'Schovávám…', { type: 'hide', key: c.key }, 'quiet')))));
}

function render(st, vaultLocked) {
  const watches = st.watches ?? [];
  watchByKey = new Map(watches.map((w) => [w.key, w]));
  // Přihlášené akce jsou jen v přehledu studenta: odkaz Odhlásit / Ověřit vede rovnou tam.
  myEventsUrl = /^https:\/\/sis\.vsem\.cz\//.test(st.sis?.signedInUrl ?? '') ? st.sis.signedInUrl : SIS_LIST_URL;
  const hidden = st.hidden ?? {};
  const { web, sisOnly } = buildCatalog(st.harmo?.rows ?? [], st.sis?.rows ?? []);
  const byKey = new Map([...web, ...sisOnly].map((c) => [c.key, c]));
  const watched = new Set(watches.map((w) => w.key));
  const hiddenSlots = new Set(Object.values(hidden).map((h) => h.slot).filter(Boolean));
  const visible = (c) => !watched.has(c.key) && !hidden[c.key] && !hiddenSlots.has(c.slot);

  renderStatus(st, vaultLocked);
  renderPulse(st);
  // Stejná ikona jako v liště Chromu, ať je stav vidět i ve velkém.
  const level = iconLevel(st, { vaultLocked });
  $('logo').src = level === 'idle' ? 'icons/48.png' : `icons/${level}-48.png`;

  const done = (w) => ['registered', 'probably'].includes(w.state);
  $('watched-section').hidden = !watches.some((w) => !done(w));
  // Bez přihlášeného SIS Šimpoliš akce nevidí: nadpis nesmí tvrdit, že hlídá.
  const stopped = st.session?.status === 'expired' || st.release?.state === 'blocked' || Boolean(st.sis?.detour);
  $('watched-title').textContent = stopped ? 'Hlídání je pozastavené' : `Šimpoliš hlídá (${watches.filter(isActive).length})`;
  // Co udělat, aby hlídání zase běželo. Jedna věta, stejná cesta jako výzva nahoře.
  const resume = !stopped
    ? []
    : st.release?.state === 'blocked'
      ? ['Hlídání se obnoví po stažení nové verze Šimpoliše']
      : st.sis?.detour && st.session?.status !== 'expired'
        ? ['Hlídání se obnoví, až v SISu vyřídíš, co po tobě chce']
      : vaultLocked && !st.vaultFailed
        ? ['Hlídání se obnoví, až povolíš Trezor nebo se ', el('a', { href: SIS_LIST_URL, target: '_blank' }, 'přihlásíš do SISu')]
        : st.vault && !st.vaultFailed
          ? ['Hlídání se obnoví hned po přihlášení do SISu']
          : st.vault
            ? ['Hlídání se obnoví, až se přihlásíš do SISu'] // Trezor selhal: cestu do SIS ukazuje červený blok
            : ['Hlídání se obnoví, až se přihlásíš do SISu. Aby se Šimpoliš do SISu přihlašoval automaticky, ',
                el('a', { href: 'options.html#vault-section', target: '_blank' }, 'založ si Trezor'), '.'];
  $('watched-resume').replaceChildren(...resume);
  $('watched-resume').hidden = !resume.length;
  $('watched-section').classList.toggle('stopped', stopped); // šachovnice zešedne: hlídka nejede
  // Chronologicky: nejbližší nahoře, akce bez termínu na konci.
  const when = (w) => (w.date ? `${w.date} ${w.time ?? '99:99'}` : '9999');
  const ordered = [...watches].sort((a, b) => when(a).localeCompare(when(b)));
  $('watched').replaceChildren(...ordered.filter((w) => !done(w)).map((w) => watchCard(w, byKey.get(w.key), autoReady(st, w, { vaultLocked }))));
  const registered = ordered.filter(done);
  $('registered-section').hidden = !registered.length;
  $('registered-title').textContent = `Přihlášeno (${registered.length})`;
  $('registered').replaceChildren(...registered.map((w) => registeredCard(w, byKey.get(w.key))));


  const webCards = web.filter(visible);
  $('web').replaceChildren(...(webCards.length ? webCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, !st.harmo?.lastCheck ? 'Šimpoliš načítá akce…' : web.length ? 'Všechny akce z harmonogramu už hlídáš nebo jsou skryté' : 'Harmonogram školy teď nemá žádnou akci s přihlašováním')]));

  const sisCards = sisOnly.filter(visible);
  $('sis-count').textContent = `(${sisCards.length})`;
  // Prázdná sekce jen překáží: schovat, pokud SIS vidím a nic dalšího v něm není.
  $('sis-section').hidden = !sisCards.length && st.session?.status === 'ok';
  $('sis').replaceChildren(...(sisCards.length ? sisCards.map((c) => eventCard(c)) : [el('li', { class: 'empty' }, st.session?.status !== 'ok' ? 'SIS není přihlášený' : sisOnly.length ? 'Všechny další akce ze SIS už hlídáš nebo jsou skryté' : 'V SIS teď není žádná další akce')]));

  const hiddenEntries = Object.entries(hidden);
  $('hidden-section').hidden = !hiddenEntries.length;
  $('hidden-count').textContent = `(${hiddenEntries.length})`;
  $('hidden').replaceChildren(
    ...hiddenEntries.map(([key, h]) =>
      el('li', { class: 'card compact' },
        el('div', { class: 'title' }, el('span', {}, h.title)),
        el('div', { class: 'actions split' }, el('span', { class: 'when' }, h.date ? formatWhen(h.date, h.time) : ''), act('Vrátit', 'Vracím…', { type: 'unhide', key })))
    )
  );

  if (focusKey) {
    const target = document.querySelector(`[data-key="${CSS.escape(focusKey)}"]`);
    if (target) {
      if (target.closest('details')) target.closest('details').open = true;
      target.classList.add('focus');
      target.scrollIntoView({ block: 'center' });
      if (params.get('cal') && calTargets.has(focusKey)) openCalendar(calTargets.get(focusKey), params.get('cal'));
      focusKey = null;
    }
  }
}

async function refresh() {
  const [st, { vaultKey }] = await Promise.all([chrome.storage.local.get(null), chrome.storage.session.get('vaultKey')]);
  const vaultLocked = Boolean(st.vault) && !vaultKey;
  render(st, vaultLocked);
  vaultState = !st.vault ? 'none' : vaultLocked ? 'locked' : st.vaultFailed ? 'failed' : 'ok';
  // Ověřit přihlášení: výrazně žlutě, dokud není SIS přihlášený, automatické přihlášení do SIS aktivní a Trezor povolený.
  $('check-now').classList.toggle('attention', !checkSummary(st, { vaultLocked }).every((p) => p.startsWith('✅') || p.startsWith('⚪')));
  // Výsledek kontroly drží krok se stavem (třeba po odemčení trezoru).
  const out = $('check-result');
  if (!out.hidden) out.replaceChildren(...checkSummary(st, { vaultLocked }).map((p) => el('span', { class: p.startsWith('❌') ? 'red' : '' }, p, fixFor(p))));
}

// Tlačítko Ověřit přihlášení: čerstvý dotaz do SIS a jednořádkový přehled, co běží a co ne.
// Automatické přihlášení do SIS trvale jen s Trezorem: založit, nebo povolit už založený.
let vaultState = 'none';
const vaultFix = () => (vaultState === 'locked' ? [' · ', el('button', { type: 'button', class: 'fix-link', onclick: openUnlock }, 'Povolit')] : [' · ', el('button', { type: 'button', class: 'fix-link', onclick: openVaultSettings }, 'Založit Trezor')]);

// Řádek výsledku kontroly, který není ✅: odkaz přímo tam, kde se to spraví.
function fixFor(line) {
  if (line.startsWith('✅')) return null;
  const link = (label, onclick) => [' · ', el('button', { type: 'button', class: 'fix-link', onclick }, label)];
  if (/SIS odhlášený/.test(line)) return link('Přihlásit do SIS', openSisLogin);
  if (/SIS po tobě něco chce|SIS neodpovídá/.test(line)) return link('Otevřít SIS', openSis);
  if (/Trezor vypnutý/.test(line)) return link('Povolit', openUnlock);
  if (/automatické přihlášení do SIS vypnuté/.test(line)) return link('Zapnout', () => send({ type: 'resume' }));
  if (/automatické přihlášení do SIS neaktivní/.test(line)) return vaultFix();
  if (/Nespárováno/.test(line)) return link('Spárovat', openPairSettings);
  if (/spárování/.test(line)) return link('Nastavení', openPairSettings);
  return link('Nastavení', openVaultSettings); // Trezor nemáš / selhal, automatické přihlášení do SIS neaktivní
}

async function checkNow() {
  const btn = $('check-now');
  const out = $('check-result');
  btn.disabled = true;
  btn.classList.add('busy');
  try {
    await send({ type: 'checkNow', force: true });
    out.hidden = false;
    await refresh();
  } finally {
    btn.disabled = false;
    btn.classList.remove('busy');
  }
}
$('check-now').addEventListener('click', checkNow);

chrome.storage.onChanged.addListener(() => refresh());
setInterval(() => refresh(), 15_000); // „před X s“ ať jde dopředu
refresh();
send({ type: 'checkNow' }); // čerstvý stav při otevření (service worker to omezí na 1× za 30 s)

// Verze vedle (beta) v hlavičce: hned vidět, co běží.
document.getElementById('beta').textContent = `(beta ${chrome.runtime.getManifest().version})`;
