// Přehled novinek pro uživatele (Nastavení, mezi Kontrolami a Diagnostikou).
// Jen nové funkce, žádné opravy chyb. Bez technických detailů, nejnovější verze první. Při každém vydání přidat položku navrch:
// test/novinky.test.js hlídá, že první položka odpovídá verzi v manifest.json.
export const NOVINKY = [
  {
    version: '0.9.3',
    items: ['Šimpoliš ukáže, s kolika dalšími počítači jsi spárovaný. Když spárování na jednom zrušíš, ostatní to poznají.'],
  },
  {
    version: '0.9.2',
    items: ['Ověřit přihlášení ukáže, jestli máš počítač spárovaný, a když ne, nabídne spárování.'],
  },
  {
    version: '0.9.1',
    items: [
      'Ověřit přihlášení ukáže i to, že je počítač spárovaný. Výsledek je přehledně ve dvou sloupcích.',
      'Šimpoliš na novém počítači nabídne spárování s tím, kde už ho máš.',
    ],
  },
  {
    version: '0.9.0',
    items: [
      'Hlídané akce můžeš mít stejné na všech svých počítačích. Stačí je spárovat v části Víc počítačů.',
      'Tlačítko Ověřit přihlášení svítí žlutě, dokud není všechno v pořádku.',
      'Tady v Nastavení přibyl přehled novinek.',
    ],
  },
  {
    version: '0.8.2',
    items: [
      'Šimpoliš pozná, že jsi na akci přihlášený, i když ses přihlásil ručně nebo z jiného počítače.',
      'Odkaz Odhlásit se v SIS vede rovnou do tvého přehledu v SIS.',
      'U výsledku Ověřit přihlášení je odkaz, kde co spravíš.',
      'Po kliknutí na Přihlásit do SIS Šimpoliš hned pozná, že ses přihlásil.',
      'V hlavičce okna vidíš, kterou verzi máš.',
    ],
  },
];
