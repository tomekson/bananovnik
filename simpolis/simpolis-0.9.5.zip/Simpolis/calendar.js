// Přidat akci do kalendáře (Google, Outlook, soubor .ics): samotnou akci, nebo čas otevření přihlášení.
// Časy v SIS i na webu školy jsou pražské; do odkazů a .ics jdou jako UTC.

const TZ = 'Europe/Prague';
const DEFAULT_MIN = 60; // konec akce neznáme: hodina

// Posun Prahy proti UTC v daný okamžik (ms), přes Intl, ať sedí i letní čas.
function pragueOffset(utcMs) {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('en-US', { timeZone: TZ, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })
      .formatToParts(new Date(utcMs))
      .map((p) => [p.type, p.value])
  );
  return Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second) - utcMs;
}

// Pražský datum + čas -> UTC ms.
export function pragueToUtc(date, time = '00:00') {
  const [y, m, d] = date.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, hh, mm);
  const first = guess - pragueOffset(guess);
  return guess - pragueOffset(first); // druhý krok pro přechod na letní/zimní čas
}

// Karta (nebo hlídání) -> událost. Konec ze SIS jen když je téhož dne (ateliéry trvají měsíce).
export function calendarEvent(c) {
  if (!c?.date) return null;
  const start = pragueToUtc(c.date, c.time ?? '00:00');
  const end = c.sis?.end?.date === c.date && c.sis.end.time && c.time ? pragueToUtc(c.date, c.sis.end.time) : null;
  const place = c.online ? (c.place && c.place !== 'online' ? `online, ${c.place}` : 'online') : c.inBuilding ? 'VŠEM, osobně' : '';
  return {
    uid: `${(c.key ?? c.title ?? 'akce').replace(/[^\w-]+/g, '-')}@simpolis`,
    title: c.title ?? c.label ?? 'Akce',
    start,
    end: end && end > start ? end : start + DEFAULT_MIN * 60_000,
    location: place,
    details: 'Přihlášení na akci najdeš v SIS: https://sis.vsem.cz/sfsis/cs_CZ/EventsCalendarSigning',
  };
}

// Připomínka přihlášení: krátká událost na čas otevření přihlášení v SIS, upozornění 10 min předem.
// Pro lidi bez Trezoru a pro ty, kdo chtějí dvojí kontrolu. Jen když je otevření ještě před námi.
export const SIGNIN_ALARM_MIN = 10;
export function signinEvent(c, now = Date.now()) {
  const from = c?.signinFrom ?? c?.sis?.signinFrom;
  if (!from?.date || !from.time) return null;
  const start = pragueToUtc(from.date, from.time);
  if (start <= now) return null;
  const title = c.title ?? c.label ?? 'akce';
  return {
    uid: `${(c.key ?? title).replace(/[^\w-]+/g, '-')}-prihlaseni@simpolis`,
    title: `Přihlas se v SIS: ${title}`,
    start,
    end: start + 15 * 60_000,
    location: 'SIS VŠEM',
    details: `Připomínka ze Šimpoliše: teď se v SIS otevírá přihlášení na akci ${title}. Přihlásit se musíš v SIS ručně: https://sis.vsem.cz/sfsis/cs_CZ/EventsCalendarSigning`,
    alarmMin: SIGNIN_ALARM_MIN,
  };
}

const utcStamp = (ms) => new Date(ms).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); // 20261214T160000Z
const utcIso = (ms) => new Date(ms).toISOString().replace(/\.\d{3}/, '');

export function googleUrl(ev) {
  const q = new URLSearchParams({ action: 'TEMPLATE', text: ev.title, dates: `${utcStamp(ev.start)}/${utcStamp(ev.end)}`, details: ev.details, location: ev.location, ctz: TZ });
  return `https://calendar.google.com/calendar/render?${q}`;
}

export function outlookUrl(ev) {
  const q = new URLSearchParams({ path: '/calendar/action/compose', rru: 'addevent', subject: ev.title, startdt: utcIso(ev.start), enddt: utcIso(ev.end), body: ev.details, location: ev.location });
  return `https://outlook.live.com/calendar/0/deeplink/compose?${q}`;
}

const icsText = (s) => String(s).replace(/\\/g, '\\\\').replace(/;/g, '\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');

export function icsFile(ev, now = Date.now()) {
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Simpolis//CS',
    'BEGIN:VEVENT',
    `UID:${ev.uid}`,
    `DTSTAMP:${utcStamp(now)}`,
    `DTSTART:${utcStamp(ev.start)}`,
    `DTEND:${utcStamp(ev.end)}`,
    `SUMMARY:${icsText(ev.title)}`,
    ev.location ? `LOCATION:${icsText(ev.location)}` : null,
    `DESCRIPTION:${icsText(ev.details)}`,
    ...(ev.alarmMin ? ['BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${icsText(ev.title)}`, `TRIGGER:-PT${Number(ev.alarmMin)}M`, 'END:VALARM'] : []),
    'END:VEVENT',
    'END:VCALENDAR',
    '',
  ].filter((l) => l !== null).join('\r\n');
}
