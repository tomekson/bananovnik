// Spárované počítače: hlídané a skryté akce mezi počítači jednoho uživatele.
// Chrome u rozbaleného rozšíření chrome.storage.sync nesynchronizuje (ověřeno 26. 11. 2026),
// proto vlastní cesta přes skript sdíleného katalogu (SHARE_URL).
//
// Párovací kód: 20 znaků (100 bitů náhody). Z kódu se odvodí
//   - ID místa ve skriptu: SHA-256("simpolis-pair-room|" + kód), hex,
//   - klíč AES-GCM: SHA-256("simpolis-pair-key|" + kód).
// Skript dostane jen ID a šifrový text (gzip + AES-GCM), obsah nikdo bez kódu nepřečte.
// Kód je uložený jen v chrome.storage.local počítačů, které ho znají.

import { SHARE_URL } from './share.js';

export const PAIR_ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // bez 0/O a 1/I
export const PAIR_LEN = 20;
export const PAIR_PULL_MS = 5 * 60_000; // jak často se ptát na změny z jiného počítače
const TIMEOUT_MS = 20_000;

export function newPairCode(random = (n) => crypto.getRandomValues(new Uint8Array(n))) {
  return [...random(PAIR_LEN)].map((b) => PAIR_ALPHABET[b % 32]).join('');
}

// Vložený kód: velká písmena, bez mezer a pomlček; záměny O→0 a I→1 nejsou v abecedě, takže chyba.
export function normalizeCode(input) {
  const c = String(input ?? '').toUpperCase().replace(/[\s-]/g, '');
  return c.length === PAIR_LEN && [...c].every((ch) => PAIR_ALPHABET.includes(ch)) ? c : null;
}

export const formatCode = (code) => code.match(/.{1,4}/g).join('-'); // ABCD-EFGH-…

const enc = new TextEncoder();
const sha = async (text) => new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(text)));
const hex = (bytes) => [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64 = (bytes) => btoa(String.fromCharCode(...bytes));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export const pairRoom = async (code) => hex(await sha(`simpolis-pair-room|${code}`));
const pairKey = async (code) => crypto.subtle.importKey('raw', await sha(`simpolis-pair-key|${code}`), 'AES-GCM', false, ['encrypt', 'decrypt']);

async function pipe(bytes, stream) {
  return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer());
}

export async function seal(code, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const packed = await pipe(enc.encode(JSON.stringify(obj)), new CompressionStream('gzip'));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await pairKey(code), packed));
  const out = new Uint8Array(iv.length + ct.length);
  out.set(iv);
  out.set(ct, iv.length);
  return b64(out);
}

export async function open(code, data) {
  const raw = unb64(data);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: raw.slice(0, 12) }, await pairKey(code), raw.slice(12));
  return JSON.parse(new TextDecoder().decode(await pipe(new Uint8Array(plain), new DecompressionStream('gzip'))));
}

// { data, at } ze skriptu; data === null = pod tímhle kódem zatím nic není.
export async function pairGet(room) {
  const res = await fetch(`${SHARE_URL}?pair=${room}`, { credentials: 'omit', cache: 'no-store', signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = JSON.parse(await res.text());
  if (!j.ok) throw new Error(j.error || 'chyba skriptu');
  return { data: j.data ?? null, at: Number(j.at) || 0 };
}

export async function pairPut(room, data) {
  const res = await fetch(SHARE_URL, {
    method: 'POST',
    credentials: 'omit',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' }, // bez preflightu, Apps Script ho neumí
    body: JSON.stringify({ pair: { room, data } }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = JSON.parse(await res.text());
  if (!j.ok) throw new Error(j.error || 'chyba skriptu');
  return Number(j.at) || Date.now();
}
