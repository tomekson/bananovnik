// Nastavení na všech počítačích se stejným účtem Chrome (chrome.storage.sync).
// Synchronizují se jen volby uživatele: které akce hlídá (a s jakým auto-přihlášením),
// které vynechal a denní souhrn. Průběžný stav hlídání, pokusy o přihlášení, SIS,
// notifikace a hlavně Trezor zůstávají jen v chrome.storage.local na každém počítači.
//
// Limity chrome.storage.sync: 8 192 B na položku (klíč + JSON), 100 kB celkem,
// 120 zápisů za minutu a 1 800 za hodinu. Proto tři malé položky, zápis jen při změně
// a staré akce se z nich mažou.

export const SYNC_KEYS = { watches: 'watches.v1', hidden: 'hidden.v1', prefs: 'prefs.v1' };
export const ITEM_MAX_BYTES = 8000; // rezerva pod QUOTA_BYTES_PER_ITEM (8 192)
export const WRITES_PER_HOUR = 600; // pojistka hluboko pod limitem 1 800/h
const KEEP_PAST_DAYS = 2;

// Jen tyhle vlastnosti hlídání jsou volba uživatele. Zbytek (state, msg, attempted, sisId, …)
// je průběžný stav konkrétního počítače.
const WATCH_FIELDS = ['key', 'source', 'label', 'date', 'time', 'online', 'inBuilding', 'place', 'namePrefix', 'confirmedName', 'confirmedId', 'rejectedNames', 'auto'];
const RUNTIME_DEFAULTS = { state: 'waiting', msg: '', attempted: false, sisId: null, sisName: null, signinFrom: null, signinTo: null, capacity: null, confirmFor: null };

const bytes = (s) => new TextEncoder().encode(s).length;
export const itemBytes = (key, value) => bytes(key) + bytes(JSON.stringify(value));

// JSON se seřazenými klíči: dva počítače musí z téhož nastavení vyrobit stejný text,
// jinak by si položku přepisovaly pořád dokola.
export function canonical(v) {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().filter((k) => v[k] !== undefined).map((k) => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
  return JSON.stringify(v ?? null);
}

const cutoff = (now) => new Date(now - KEEP_PAST_DAYS * 24 * 3600_000).toISOString().slice(0, 10);
const recent = (date, now) => !date || date >= cutoff(now);

export function watchDef(w) {
  const d = {};
  for (const f of WATCH_FIELDS) d[f] = w[f] ?? null;
  d.auto = Boolean(w.auto);
  d.rejectedNames = Array.isArray(w.rejectedNames) ? w.rejectedNames.slice(-10) : [];
  return d;
}

// Lokální stav -> položky pro chrome.storage.sync. Když se něco nevejde, zahodí nejstarší
// a vrátí varování (Šimpoliš na tomhle počítači funguje dál, jen se to nesdílí).
export function toSync(st, now = Date.now()) {
  const warnings = [];
  let watches = (st.watches ?? []).filter((w) => recent(w.date, now)).map(watchDef)
    .sort((a, b) => `${a.date}|${a.time}|${a.key}`.localeCompare(`${b.date}|${b.time}|${b.key}`));
  while (watches.length && itemBytes(SYNC_KEYS.watches, watches) > ITEM_MAX_BYTES) {
    watches = watches.slice(0, -1); // nejvzdálenější akce
    warnings.push('Hlídaných akcí je moc, nejvzdálenější se nesdílí.');
  }
  let hiddenEntries = Object.entries(st.hidden ?? {})
    .filter(([, h]) => recent(h?.date, now))
    .map(([k, h]) => [k, { title: String(h?.title ?? k).slice(0, 120), date: h?.date ?? null, time: h?.time ?? null, slot: h?.slot ?? null }])
    .sort(([, a], [, b]) => `${b.date}`.localeCompare(`${a.date}`)); // nejnovější první
  while (hiddenEntries.length && itemBytes(SYNC_KEYS.hidden, Object.fromEntries(hiddenEntries)) > ITEM_MAX_BYTES) {
    hiddenEntries = hiddenEntries.slice(0, -1);
    warnings.push('Skrytých akcí je moc, nejstarší se nesdílí.');
  }
  return {
    items: {
      [SYNC_KEYS.watches]: watches,
      [SYNC_KEYS.hidden]: Object.fromEntries(hiddenEntries),
      [SYNC_KEYS.prefs]: { heartbeat: st.heartbeat !== false, sisOpen: st.sisOpen !== false },
    },
    warnings: [...new Set(warnings)],
  };
}

// Které položky se od posledního zápisu změnily (podle kanonického JSON).
export function changedItems(items, sent = {}) {
  return Object.fromEntries(Object.entries(items).filter(([k, v]) => sent[k] !== canonical(v)));
}

// Položky ze sync -> lokální stav. Hlídání, které je jinde zrušené, zmizí; nové přibude
// s čerstvým stavem; u existujícího se přepíšou jen volby uživatele, průběžný stav zůstane.
export function applySync(st, data) {
  const defs = data[SYNC_KEYS.watches];
  if (Array.isArray(defs)) {
    const local = new Map((st.watches ?? []).map((w) => [w.key, w]));
    st.watches = defs.filter((d) => d?.key && d.source).map((d) => {
      const w = local.get(d.key);
      if (!w) return { ...RUNTIME_DEFAULTS, ...d, updatedAt: Date.now() };
      const wasAuto = w.auto;
      for (const f of WATCH_FIELDS) w[f] = d[f];
      if (wasAuto && !w.auto && w.state === 'confirm') Object.assign(w, { state: 'waiting', msg: '' });
      return w;
    });
  }
  const hidden = data[SYNC_KEYS.hidden];
  if (hidden && typeof hidden === 'object' && !Array.isArray(hidden)) st.hidden = structuredClone(hidden);
  const prefs = data[SYNC_KEYS.prefs];
  if (prefs && typeof prefs === 'object' && typeof prefs.heartbeat === 'boolean') st.heartbeat = prefs.heartbeat;
  if (prefs && typeof prefs === 'object' && typeof prefs.sisOpen === 'boolean') st.sisOpen = prefs.sisOpen; // rozbalená sekce Další akce v SIS
  return st;
}

// Jednorázová migrace z chrome.storage.local: sloučit to, co už je v sync (z jiného počítače),
// s tím, co má tenhle počítač. Nic se neztratí; při shodě klíče vyhrává sync.
export function mergeForMigration(data, st) {
  const out = {};
  const syncWatches = Array.isArray(data[SYNC_KEYS.watches]) ? data[SYNC_KEYS.watches] : [];
  const have = new Set(syncWatches.map((d) => d.key));
  out[SYNC_KEYS.watches] = [...syncWatches, ...(st.watches ?? []).filter((w) => w.key && w.source && !have.has(w.key)).map(watchDef)];
  out[SYNC_KEYS.hidden] = { ...(st.hidden ?? {}), ...(data[SYNC_KEYS.hidden] ?? {}) };
  out[SYNC_KEYS.prefs] = data[SYNC_KEYS.prefs] ?? { heartbeat: st.heartbeat !== false, sisOpen: st.sisOpen !== false };
  return out;
}

// Sloučení změn ze dvou počítačů proti společnému základu (poslední stav, který oba znaly).
// Co tenhle počítač od základu přidal nebo změnil, vyhrává; co smazal, zmizí; zbytek bere druhý počítač.
export function mergeThreeWay(base = {}, local = {}, remote = {}) {
  const W = SYNC_KEYS.watches;
  const H = SYNC_KEYS.hidden;
  const P = SYNC_KEYS.prefs;
  const byKey = (arr) => new Map((Array.isArray(arr) ? arr : []).filter((d) => d?.key).map((d) => [d.key, d]));
  const entries = (o) => new Map(Object.entries(o && typeof o === 'object' && !Array.isArray(o) ? o : {}));
  const merge = (b, l, r) => {
    const out = new Map(r);
    for (const [k, v] of l) if (!b.has(k) || canonical(b.get(k)) !== canonical(v)) out.set(k, v);
    for (const k of b.keys()) if (!l.has(k)) out.delete(k);
    return out;
  };
  return {
    [W]: [...merge(byKey(base[W]), byKey(local[W]), byKey(remote[W])).values()],
    [H]: Object.fromEntries(merge(entries(base[H]), entries(local[H]), entries(remote[H]))),
    [P]: canonical(local[P]) !== canonical(base[P]) ? local[P] : (remote[P] ?? local[P]),
  };
}
