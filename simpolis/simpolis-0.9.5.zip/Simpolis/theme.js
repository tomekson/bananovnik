// Vzhled okna a Nastavení (Nastavení → Vzhled). Běží v <head> ještě před vykreslením, ať stránka neproblikne.
try {
  const t = localStorage.getItem('theme');
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
} catch {
  /* bez localStorage platí vzhled systému */
}
