// Přehled novinek pro uživatele (Nastavení, mezi Kontrolami a Diagnostikou).
// Jen nové funkce, žádné opravy chyb. Bez technických detailů, nejnovější verze první.
// Verze jen s opravami položku nemá; test/novinky.test.js hlídá, že první položka není novější než manifest.
export const NOVINKY = [
  {
    version: '0.9.7',
    items: ['Ranní zprávu najdeš i v okně Šimpoliše, kdybys notifikaci propásl.'],
  },
  {
    version: '0.9.6',
    items: ['Když máš Trezor a není povolený, ikona šimpanze v liště zčervená. Uvidíš to, i když je SIS přihlášený.'],
  },
  {
    version: '0.9.5',
    items: ['Šimpoliš pozná, když IPC navýší kapacitu akce. Přihlášeným dál ukazuje ✅ Přihlášeno, ostatním nová volná místa.'],
  },
  {
    version: '0.9.4',
    items: ['Sekce Další akce v SIS je rozbalená. Když ji sbalíš, Šimpoliš si to zapamatuje i na spárovaných počítačích.'],
  },
  {
    version: '0.9.3',
    items: ['Šimpoliš ukáže, s kolika dalšími počítači jsi spárovaný. Když spárování na jednom zrušíš, ostatní to poznají.'],
  },
  {
    version: '0.9.2',
    items: ['Ověřit přihlášení ukáže, jestli máš počítač spárovaný, a když ne, nabídne spárování.'],
  },
  {
    version: '0.9.1',
    items: [
      'Ověřit přihlášení ukáže i to, že je počítač spárovaný. Výsledek je přehledně ve dvou sloupcích.',
      'Šimpoliš na novém počítači nabídne spárování s tím, kde už ho máš.',
    ],
  },
  {
    version: '0.9.0',
    items: [
      'Hlídané akce můžeš mít stejné na všech svých počítačích. Stačí je spárovat v části Víc počítačů.',
      'Tlačítko Ověřit přihlášení svítí žlutě, dokud není všechno v pořádku.',
      'Tady v Nastavení přibyl přehled novinek.',
    ],
  },
  {
    version: '0.8.2',
    items: [
      'Šimpoliš pozná, že jsi na akci přihlášený, i když ses přihlásil ručně nebo z jiného počítače.',
      'Odkaz Odhlásit se v SIS vede rovnou do tvého přehledu v SIS.',
      'U výsledku Ověřit přihlášení je odkaz, kde co spravíš.',
      'Po kliknutí na Přihlásit do SIS Šimpoliš hned pozná, že ses přihlásil.',
      'V hlavičce okna vidíš, kterou verzi máš.',
    ],
  },
];
